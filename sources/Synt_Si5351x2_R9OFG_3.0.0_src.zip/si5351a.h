﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * si5351a.h
 *
 * Author: R9OFG (ex R0AEK)
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#ifndef SI5351A_H
#define SI5351A_H

#include <inttypes.h>

/*--- адреса регистров Si5351 ---------------------------------------------*/
#define SI_CLK0_CONTROL		16
#define SI_CLK1_CONTROL		17
#define SI_CLK2_CONTROL		18
#define SI_SYNTH_PLL_A		26
#define SI_SYNTH_MS_0		42
#define SI_PLL_RESET		177

/*--- коэффициенты R-делителя ---------------------------------------------*/
#define SI_R_DIV_1			0b00000000
#define SI_R_DIV_2			0b00010000
#define SI_R_DIV_4			0b00100000
#define SI_R_DIV_8			0b00110000
#define SI_R_DIV_16			0b01000000
#define SI_R_DIV_32			0b01010000
#define SI_R_DIV_64			0b01100000
#define SI_R_DIV_128		0b01110000

#define SI_CLK_SRC_PLL_A	0b00000000

/*--- параметры расчёта ---------------------------------------------------*/
#define FREQ_PLLA			900000000UL		/* частота PLLA, Гц */
#define ACTUAL_MULTIPLIER	1048575UL		/* максимальный знаменатель, 20 бит */

/*
 * Номер микросхемы. Задаёт, какая опорная частота (xtall_FREQ_1/2) и какой
 * ток драйвера (siDSC_1/2) используются. Физический выбор микросхемы на шине
 * I2C выполняется мультиплексором линии SCL1 (см. SCL_1_line_Control()).
 */
#define SI_CHIP_1			0				/* Si5351-1 (VFO) */
#define SI_CHIP_2			1				/* Si5351-2 (BFO) */

/*
 * Допустимый диапазон выходной частоты.
 * Нижняя граница задана схемотехникой: при PLLA = 900 МГц делитель
 * MultiSynth не может быть больше 900.
 */
#define SI_FREQ_MIN			1000000UL
#define SI_FREQ_MAX			60000000UL

void si5351aOutputOff(uint8_t value);
void set_drvSt_si5351(uint8_t value);
void si5351aSetFrequency(uint32_t frequency, uint8_t chip);

#endif /* SI5351A_H */
