﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * Main.c
 *
 * Project modified:		14.11.2026
 * Author:				R9OFG (ex R0AEK)
 * Version:				3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 *
 * Отличия от версии 2.3 — только исправление ошибок и чистка, состав функций
 * (кнопки, меню, CAT, диапазоны) не изменён.
 */

#include "Main.h"

/*--- прототипы внутренних функций ----------------------------------------*/
static uint32_t Clamp_Freq(uint32_t value, uint32_t min, uint32_t max);
static uint32_t Step_Freq(uint32_t value, uint8_t dir, uint32_t min, uint32_t max);
static uint8_t  Button_Hold_At_Least(uint16_t min_ms);
static void     Write_Default_EEPROM(void);
static void     SCL_1_line_Control(uint8_t value);
static void     Calc_Out_Freq_Si5351(void);
static void     S_METR(void);
static void     SR_Write(uint8_t data);
static void     ATT_PRE_Pins(void);
static void     ATT_PRE_Label(void);
static void     ATT_PRE_Refresh(void);
static uint32_t BFO_Get_Freq(void);
static void     Set_MODE_L(void);
static void     Set_MODE_H(void);
static void     Band_Label_to_LCD(void);
static void     Step_Value_to_LCD(void);
static void     Change_STEP(uint8_t value);
static void     Setup_info_to_LCD(const char *infoStr);
static void     Set_BFO(uint8_t value);
static void     Set_XTALL(uint8_t value);
static void     Set_use_BAND(uint8_t value);
static void     DrvST_to_LCD(uint8_t value);
static void     Set_DRV_ST(uint8_t value);
static void     Set_Conversion(uint8_t value);
static void     Set_Swap_F_TX(uint8_t value);
static void     Select_First_Enabled_Band(void);
static void     Change_VFO(uint8_t value);
static void     BandDataSaved(void);
static void     Button_PAD(void);
static void     Encoder_Up(void);
static void     Encoder_Down(void);
static void     TIMER1_Init(void);
static void     ADC_Init(void);

/*--- константы -----------------------------------------------------------*/
#define STEP_COUNT	7

#define PIN_ATT		(1 << 4)		/* выход ATT */
#define PIN_PRE		(1 << 5)		/* выход PRE */
#define PIN_CW		(1 << 6)		/* выход CW */
#define PIN_PTT		(1 << 7)		/* выход PTT */

#define SAVE_BAND_DATA_TICKS	4000	/* ~1.28 с до сохранения частоты */
#define SAVE_BAND_DATA_IDLE		0xFFFF

/*
 * Период прерывания таймера 1: 1000 тактов при F_CPU/8 = 320 мкс.
 * Выдержки кнопок задаются в миллисекундах и пересчитываются в тики таймера.
 */
#define TIMER1_TICK_US			320UL
#define MS_TO_TICKS(ms)			((uint16_t)(((uint32_t)(ms) * 1000UL) / TIMER1_TICK_US))

#define BTN_DEBOUNCE_MS			32		/* антидребезг кнопок */
#define FUNC_SHORT_MAX_MS		1000	/* короткое нажатие FUNC */
#define FUNC_STEP_MIN_MS		1000	/* удержание 1...5 с — выбор шага */
#define FUNC_SETUP_MIN_MS		5000	/* удержание от 5 с — вход в настройки */
#define BTN_TAP_MIN_MS			32		/* ATT/PRE и MODE: нажатие от 32 мс */
#define BTN_PTT_HOLD_MIN_MS		64		/* PTT: нажатие от 64 мс */
#define BTN_COUNT_MAX			60000	/* насыщение счётчика удержания */

/*
 * S-метр: без фильтрации и гистерезиса на границе порога кубики дребезжали
 * (уровень переключался на каждом отсчёте АЦП). Теперь:
 *  - АЦП S-метра читается 10-битным и пересчитывается в 0...255 для диапазона
 *    0...1,2 В (ADS-шкала 5 В используется иначе лишь на 13 %);
 *  - отсчёт сглаживается экспоненциальным средним (1/128, ~40 мс) прямо
 *    в прерывании: шум и «дыхание» сигнала сильно уменьшаются;
 *  - вверх переходим по порогу, вниз — только когда сигнал ушёл ниже порога
 *    на SMETR_HYST_ADC (гистерезис); подтверждение по времени не нужно, так
 *    как отсчёт уже сглажен (иначе на границе порога кубики дребезжали).
 */
#define SMETR_FILTER_SHIFT		7		/* сглаживание 1/128 (~40 мс) */
#define SMETR_HYST_ADC			2		/* гистерезис порогов, единицы АЦП */

/*--- переменные ----------------------------------------------------------*/
volatile unsigned char butBuf			= BUT_NULL;	/* буфер кнопок */
volatile unsigned char data_ADC_1		= 0;		/* результат АЦП1 (сырой) */
volatile unsigned char data_ADC_1_filt	= 0;		/* АЦП1 после сглаживания */
static uint16_t adc1_Filt				= 0;		/* накопитель сглаживания, 1/256 */
static volatile uint8_t adc1_Sample_New	= 0;		/* готов новый отсчёт АЦП1 */

int8_t   old_S_metr_Value				= -2;		/* предыдущее показание S-метра */

volatile unsigned int but_Count_Pressed	= 0;		/* счётчик удержания кнопки */
uint8_t  but_ATT_PRE					= 0;		/* 0 - off, 1 - ATT, 2 - PRE */
uint8_t  but_MODE						= 0;		/* 0 - LSB, 1 - USB, 2 - CWL, 3 - CWU */
volatile uint8_t butPress_F				= 0;		/* кнопка нажата */
uint8_t  ptt_cat_ON_F					= 0;		/* PTT включён по CAT */
volatile uint8_t butPressFUNC			= 0;		/* нажата кнопка FUNC */
uint8_t  modeSetup						= 0;		/* текущий пункт меню настроек */
static uint8_t button_Action_Done		= 0;		/* действие по уровню уже выполнено */

volatile uint8_t next_state;							/* опрос энкодера */
volatile uint8_t prev_state;
volatile uint8_t up_state;
volatile uint8_t down_state;

uint8_t  ABCD_Code						= 0x00;		/* состояние регистра сдвига */

uint8_t  func_Mode						= FUNC_MODE_NORMAL;
char     TempStr[10]					= "";		/* буфер для перевода числа в строку */
unsigned char band_Num					= BAND_40m;	/* номер текущего диапазона */

/* массив частот диапазонов по умолчанию (в FLASH) */
static const uint32_t band_F_BUFF[BANDS_COUNT] PROGMEM =
	{1840000, 3600000, 7100000, 10130000, 14101000, 18111000, 21151000, 24931000, 28225000};

/* массив последних установленных частот диапазонов */
uint32_t band_last_F_BUFF[BANDS_COUNT] =
	{1840000, 3600000, 7100000, 10130000, 14101000, 18111000, 21151000, 24931000, 28225000};

/* метки диапазонов (в FLASH) */
static const char band_Label[BANDS_COUNT][5] PROGMEM =
	{"160m", "80m", "40m", "30m", "20m", "17m", "15m", "12m", "10m"};

/* значения шага перестройки, Гц (в FLASH) */
static const uint32_t step_Value[STEP_COUNT] PROGMEM =
	{1, 10, 100, 500, 1000, 10000, 100000};

uint32_t freq_BFO_LSB					= FREQ_LSB_DEF;
uint32_t freq_BFO_USB					= FREQ_USB_DEF;
uint32_t freq_BFO_CWL					= FREQ_CWL_DEF;
uint32_t freq_BFO_CWU					= FREQ_CWU_DEF;
uint32_t freq_VFO						= 7100000UL;
uint32_t xtall_FREQ_1					= FREQ_XTALL_1_DEF;
uint32_t xtall_FREQ_2					= FREQ_XTALL_2_DEF;
uint32_t freq_si						= 0;

uint8_t  att_pre[BANDS_COUNT]			= {0,0,0,0,0,0,0,0,0};
uint8_t  band_use[BANDS_COUNT]			= {1,1,1,1,1,1,1,1,1};

/* пороги S-метра по умолчанию (АЦП с опорой 1,1 В, 0...255) */
static const uint8_t smetr_cal_def[SMETR_CAL_COUNT] PROGMEM = {9, 27, 50, 73, 96, 115, 134};

/* пороги S-метра: 1-й кубик ... 7-й кубик (0...255) */
uint8_t smetr_cal[SMETR_CAL_COUNT] = {9, 27, 50, 73, 96, 115, 134};

uint32_t set_Step						= 0;
volatile uint16_t timerCountSaveBandData = 0;
static volatile uint8_t flag_Save_BandData = 0;
uint8_t  set_Step_index					= 0;
uint8_t  set_Step_F						= 0;
uint8_t  bandDataNum					= 0;
uint8_t  siDSC_1						= 0;
uint8_t  siDSC_2						= 0;
uint8_t  var_Conversion					= 0;
uint8_t  var_Swap_F_TX					= 0;

/*--- вспомогательные функции ---------------------------------------------*/

static uint32_t Clamp_Freq(uint32_t value, uint32_t min, uint32_t max)
{
	if (value < min) return min;
	if (value > max) return max;
	return value;
}

/*
 * Изменение частоты на один шаг с защитой от переполнения.
 * Раньше вычитание ниже нуля давало огромное число, которое затем
 * «прилипало» к верхней границе.
 */
static uint32_t Step_Freq(uint32_t value, uint8_t dir, uint32_t min, uint32_t max)
{
	if (dir == 1)
	{
		if (value <= max - set_Step) value += set_Step;
		else                         value = max;
	}
	else if (dir == 2)
	{
		if (value >= min + set_Step) value -= set_Step;
		else                         value = min;
	}

	return Clamp_Freq(value, min, max);
}

/* кнопка удерживается не меньше min_ms */
static uint8_t Button_Hold_At_Least(uint16_t min_ms)
{
	return (uint8_t)(but_Count_Pressed > MS_TO_TICKS(min_ms));
}

/*
 * Запись заводских установок. Вызывается, если в EEPROM нет маркера формата
 * (первый запуск после смены формата данных — частота хранится как dword, а
 * не как float).
 */
static void Write_Default_EEPROM(void)
{
	eeprom_write_byte((uint8_t*)EE_ADDR_STEP, 3);			/* шаг 500 Гц */
	eeprom_write_byte((uint8_t*)EE_ADDR_BAND, BAND_40m);
	eeprom_write_dword((uint32_t*)EE_ADDR_BFO_LSB, FREQ_LSB_DEF);
	eeprom_write_dword((uint32_t*)EE_ADDR_BFO_USB, FREQ_USB_DEF);
	eeprom_write_dword((uint32_t*)EE_ADDR_BFO_CWL, FREQ_CWL_DEF);
	eeprom_write_dword((uint32_t*)EE_ADDR_BFO_CWU, FREQ_CWU_DEF);
	eeprom_write_dword((uint32_t*)EE_ADDR_XTALL_1, FREQ_XTALL_1_DEF);
	eeprom_write_dword((uint32_t*)EE_ADDR_XTALL_2, FREQ_XTALL_2_DEF);
	eeprom_write_byte((uint8_t*)EE_ADDR_DRV_ST_1, 0);
	eeprom_write_byte((uint8_t*)EE_ADDR_DRV_ST_2, 0);
	eeprom_write_byte((uint8_t*)EE_ADDR_CONV, 0);
	eeprom_write_byte((uint8_t*)EE_ADDR_SWAP_TX, 0);

	for (uint8_t i = 0; i < BANDS_COUNT; i++)
	{
		eeprom_write_dword((uint32_t*)(EE_ADDR_BAND_FREQ + 4 * i),
		                   pgm_read_dword(&band_F_BUFF[i]));
		eeprom_write_byte((uint8_t*)(EE_ADDR_ATT_PRE + i), 0);
		eeprom_write_byte((uint8_t*)(EE_ADDR_BAND_USE + i), 1);
	}

	/* пороги S-метра */
	for (uint8_t i = 0; i < SMETR_CAL_COUNT; i++)
	{
		eeprom_write_byte((uint8_t*)(EE_ADDR_SMETR_CAL + i), pgm_read_byte(&smetr_cal_def[i]));
	}

	/* маркер пишем последним */
	eeprom_write_byte((uint8_t*)EE_ADDR_FORMAT, EE_FORMAT_MARK);
}

void Read_Setup_EEPROM(void)
{
	uint8_t i;

	/* если формат данных не наш — переписываем все установки */
	if (eeprom_read_byte((uint8_t*)EE_ADDR_FORMAT) != EE_FORMAT_MARK)
		Write_Default_EEPROM();

	/* шаг перестройки (хранится индекс массива step_Value) */
	set_Step_index = eeprom_read_byte((uint8_t*)EE_ADDR_STEP);
	if (set_Step_index >= STEP_COUNT) set_Step_index = 3;
	set_Step = pgm_read_dword(&step_Value[set_Step_index]);

	/* последний активный диапазон */
	band_Num = eeprom_read_byte((uint8_t*)EE_ADDR_BAND);
	if ((band_Num < 1) || (band_Num > BANDS_COUNT)) band_Num = BAND_40m;

	/* частоты BFO */
	freq_BFO_LSB = eeprom_read_dword((uint32_t*)EE_ADDR_BFO_LSB);
	freq_BFO_USB = eeprom_read_dword((uint32_t*)EE_ADDR_BFO_USB);
	freq_BFO_CWL = eeprom_read_dword((uint32_t*)EE_ADDR_BFO_CWL);
	freq_BFO_CWU = eeprom_read_dword((uint32_t*)EE_ADDR_BFO_CWU);

	/* частоты опорных генераторов */
	xtall_FREQ_1 = eeprom_read_dword((uint32_t*)EE_ADDR_XTALL_1);
	xtall_FREQ_2 = eeprom_read_dword((uint32_t*)EE_ADDR_XTALL_2);

	/* последние частоты диапазонов, ATT/PRE и разрешение диапазонов */
	for (i = 0; i < BANDS_COUNT; i++)
	{
		band_last_F_BUFF[i] = eeprom_read_dword((uint32_t*)(EE_ADDR_BAND_FREQ + 4 * i));

		if ((band_last_F_BUFF[i] < FREQ_VFO_MIN) || (band_last_F_BUFF[i] > FREQ_VFO_MAX))
			band_last_F_BUFF[i] = pgm_read_dword(&band_F_BUFF[i]);

		att_pre[i] = eeprom_read_byte((uint8_t*)(EE_ADDR_ATT_PRE + i));
		if (att_pre[i] > 2) att_pre[i] = 0;

		band_use[i] = eeprom_read_byte((uint8_t*)(EE_ADDR_BAND_USE + i));
		if (band_use[i] > 1) band_use[i] = 1;
	}

	/* ток драйвера CLK0 */
	siDSC_1 = eeprom_read_byte((uint8_t*)EE_ADDR_DRV_ST_1);
	if (siDSC_1 > 3) siDSC_1 = 0;

	siDSC_2 = eeprom_read_byte((uint8_t*)EE_ADDR_DRV_ST_2);
	if (siDSC_2 > 3) siDSC_2 = 0;

	/* вариант преобразования и смена частот при TX */
	var_Conversion = eeprom_read_byte((uint8_t*)EE_ADDR_CONV);
	if (var_Conversion > 1) var_Conversion = 0;

	var_Swap_F_TX = eeprom_read_byte((uint8_t*)EE_ADDR_SWAP_TX);
	if (var_Swap_F_TX > 1) var_Swap_F_TX = 0;

	/*
	 * Пороги S-метра. Шкала сменилась: АЦП S-метра теперь работает от
	 * внутренней опоры 1,1 В, поэтому старые пороги (опора AVcc) не подходят.
	 * Признак шкалы лежит рядом с порогами — при несовпадении ставим новые
	 * значения по умолчанию, остальные настройки не трогаем.
	 */
	if (eeprom_read_byte((uint8_t*)EE_ADDR_SMETR_TYPE) != SMETR_TYPE_1V1)
	{
		for (i = 0; i < SMETR_CAL_COUNT; i++)
		{
			smetr_cal[i] = pgm_read_byte(&smetr_cal_def[i]);
			eeprom_update_byte((uint8_t*)(EE_ADDR_SMETR_CAL + i), smetr_cal[i]);
		}

		eeprom_update_byte((uint8_t*)EE_ADDR_SMETR_TYPE, SMETR_TYPE_1V1);
	}
	else
	{
		uint8_t bad = 0;

		for (i = 0; i < SMETR_CAL_COUNT; i++)
		{
			smetr_cal[i] = eeprom_read_byte((uint8_t*)(EE_ADDR_SMETR_CAL + i));

			if (smetr_cal[i] == 0xFF) bad = 1;
			if ((i > 0) && (smetr_cal[i] <= smetr_cal[i - 1])) bad = 1;
		}

		if (bad)
		{
			for (i = 0; i < SMETR_CAL_COUNT; i++)
			{
				smetr_cal[i] = pgm_read_byte(&smetr_cal_def[i]);
				eeprom_update_byte((uint8_t*)(EE_ADDR_SMETR_CAL + i), smetr_cal[i]);
			}
		}
	}
}

/*
 * Выбор микросхемы на шине I2C: 0 - Si5351-1 (VFO), 1 - Si5351-2 (BFO).
 */
static void SCL_1_line_Control(uint8_t value)
{
	if (value)
		PORTC &= ~(1 << SW_I2C);	/* линия SCL1 прижата к земле — Si5351-2 */
	else
		PORTC |= (1 << SW_I2C);		/* линия отпущена — Si5351-1 */

	_delay_ms(2);
}

/* расчёт выходной частоты Si5351 (VFO) с учётом варианта преобразования */
static void Calc_Out_Freq_Si5351(void)
{
	if (var_Conversion == 1)
	{
		/* «всегда вверх» */
		switch (but_MODE)
		{
			case 0:  freq_si = freq_VFO + freq_BFO_LSB; break;	/* LSB */
			case 1:  freq_si = freq_VFO + freq_BFO_USB; break;	/* USB */
			case 2:  freq_si = freq_VFO + freq_BFO_CWL; break;	/* CWL */
			default: freq_si = freq_VFO + freq_BFO_CWU; break;	/* CWU */
		}
	}
	else
	{
		/* классическое преобразование */
		switch (but_MODE)
		{
			case 0:  freq_si = freq_VFO + freq_BFO_LSB; break;	/* LSB */
			case 1:  freq_si = freq_VFO - freq_BFO_LSB; break;	/* USB */
			case 2:  freq_si = freq_VFO + freq_BFO_CWL; break;	/* CWL */
			default: freq_si = freq_VFO - freq_BFO_CWL; break;	/* CWU */
		}
	}
}

/* показания S-метра на второй строке LCD: 1...7 «кубиков» */
static void S_METR(void)
{
	uint8_t adc;
	int8_t  level;
	uint8_t i;

	/* каждый отсчёт АЦП обрабатываем ровно один раз */
	if (!adc1_Sample_New) return;
	adc1_Sample_New = 0;

	/* сглаженное значение (фильтр работает в прерывании АЦП) */
	adc = data_ADC_1_filt;

	/*
	 * Полная перерисовка (после включения, выхода из меню и т. п.): стираем
	 * всю зону S-метра, дальше считаем от «ни одного кубика».
	 */
	if (old_S_metr_Value < -1)
	{
		/* значок антенны и очистка шкалы кубиков */
		LCD_set_pos(8, 1);
		LCD_send_char(0);

		for (i = 9; i < 16; i++)
		{
			LCD_set_pos(i, 1);
			LCD_send_char(' ');
		}

		old_S_metr_Value = -1;
	}

	/*
	 * Новый уровень считаем от текущего показания с гистерезисом: вверх —
	 * по превышению порога, вниз — только когда сигнал ушёл ниже порога на
	 * SMETR_HYST_ADC. Иначе на границе порога кубики дребезжали.
	 */
	level = old_S_metr_Value;

	while ((level < (int8_t)(SMETR_CAL_COUNT - 1)) &&
	       ((int16_t)adc >= (int16_t)smetr_cal[level + 1]))
		level++;

	while ((level >= 0) &&
	       ((int16_t)adc < (int16_t)(smetr_cal[level] - SMETR_HYST_ADC)))
		level--;

	if (level == old_S_metr_Value) return;

	if (level < old_S_metr_Value)
	{
		/* стираем кубики правее нового уровня */
		for (i = (uint8_t)(9 + level + 1); i < 16; i++)
		{
			LCD_set_pos(i, 1);
			LCD_send_char(' ');
		}
	}
	else
	{
		/*
		 * Рисуем только появившиеся кубики: знакоместо 8 — антенна,
		 * кубики идут с 9-го, в CGRAM это значки 1...7.
		 */
		for (i = (uint8_t)(old_S_metr_Value + 1); i <= (uint8_t)level; i++)
		{
			LCD_set_pos((uint8_t)(9 + i), 1);
			LCD_send_char((uint8_t)(i + 1));
		}
	}

	old_S_metr_Value = level;
}

/* запись байта в регистр сдвига (ДПФ, ATT/PRE, CW, PTT) */
static void SR_Write(uint8_t data)
{
	ABCD_Code = data;

	for (uint8_t i = 0; i < 8; i++)
	{
		if (data & 0x80) PORTD |= (1 << SR_DATA);
		else             PORTD &= ~(1 << SR_DATA);

		PORTD |= (1 << SR_CLOCK);
		PORTD &= ~(1 << SR_CLOCK);
		data <<= 1;
	}

	PORTD |= (1 << SR_LATCH);
	PORTD &= ~(1 << SR_LATCH);
}

/* установка выходов ATT/PRE (биты 4 и 5 регистра сдвига) */
static void ATT_PRE_Pins(void)
{
	ABCD_Code &= (uint8_t)~(PIN_ATT | PIN_PRE);

	if (but_ATT_PRE == 1)      ABCD_Code |= PIN_ATT;
	else if (but_ATT_PRE == 2) ABCD_Code |= PIN_PRE;

	SR_Write(ABCD_Code);
}

/* вывод ATT/PRE на LCD (позиция 4, вторая строка) */
static void ATT_PRE_Label(void)
{
	LCD_set_pos(4, 1);

	for (uint8_t i = 0; i < 3; i++)
		LCD_send_char(' ');

	if (but_ATT_PRE == 1)
	{
		LCD_set_pos(4, 1);
		LCD_send_str_P(PSTR("ATT"));
	}
	else if (but_ATT_PRE == 2)
	{
		LCD_set_pos(4, 1);
		LCD_send_str_P(PSTR("PRE"));
	}
}

/* обновление ATT/PRE без записи EEPROM и без ответа в CAT */
static void ATT_PRE_Refresh(void)
{
	ATT_PRE_Pins();
	ATT_PRE_Label();
}

/*
 * Изменение ATT/PRE по действию пользователя: выходы, LCD, EEPROM, ответ CAT.
 * Раньше эта функция вызывалась и при смене диапазона, из-за чего EEPROM
 * перезаписывался при каждом переключении, а в CAT уходил лишний ответ.
 */
void ATT_PRE_Set(void)
{
	att_pre[band_Num - 1] = but_ATT_PRE;

	eeprom_update_byte((uint8_t*)(EE_ADDR_ATT_PRE + band_Num - 1), but_ATT_PRE);

	ATT_PRE_Refresh();

	/* ответ в USART (необходим для CAT) */
	CAT_ATT_PRE_Send(0);
}

/*
 * Переключение ATT/PRE по нажатию: ATT -> нет -> PRE -> нет -> ATT ...
 * (было off -> ATT -> PRE -> off, т.е. «нет» встречалось только после PRE).
 * Состояние «нет» запоминается как 0, поэтому после выключения следующим
 * включается противоположное.
 */
void ATT_PRE_Toggle(void)
{
	static uint8_t next_on = 1;		/* что включить из состояния «нет»: 1 = ATT, 2 = PRE */

	if (but_ATT_PRE == 0)
	{
		but_ATT_PRE = next_on;
		next_on = (next_on == 1) ? 2 : 1;
	}
	else
	{
		but_ATT_PRE = 0;
	}

	ATT_PRE_Set();
}

/* частота BFO для текущей моды и варианта преобразования */
static uint32_t BFO_Get_Freq(void)
{
	if (var_Conversion == 0)
	{
		/* классическое преобразование: BFO всегда ниже/ниже полосы */
		if (but_MODE <= 1) return freq_BFO_LSB;
		return freq_BFO_CWL;
	}

	switch (but_MODE)
	{
		case 0:  return freq_BFO_LSB;
		case 1:  return freq_BFO_USB;
		case 2:  return freq_BFO_CWL;
		default: return freq_BFO_CWU;
	}
}

/* PTT: 1 - передача, 0 - приём */
void PTT_ON(uint8_t value)
{
	if (value == 1)
	{
		func_Mode = FUNC_MODE_TX;

		/* смена частот VFO/BFO_xxx при передаче */
		if (var_Swap_F_TX == 1)
		{
			SCL_1_line_Control(1);
			si5351aSetFrequency(freq_si, SI_CHIP_2);		/* VFO -> Si5351-2 */
			SCL_1_line_Control(0);
			si5351aSetFrequency(BFO_Get_Freq(), SI_CHIP_1);	/* BFO -> Si5351-1 */
		}

		/* снимаем ATT/PRE и включаем PTT одним циклом записи */
		ABCD_Code = (uint8_t)((ABCD_Code & (uint8_t)~(PIN_ATT | PIN_PRE)) | PIN_PTT);
		SR_Write(ABCD_Code);

		LCD_set_pos(0, 0);
		LCD_send_str_P(PSTR("TX-ON"));

		LCD_set_pos(4, 1);
		for (uint8_t i = 0; i < 12; i++) LCD_send_char(' ');

		/* область S-метра стёрта — после возврата в RX её надо перерисовать */
		old_S_metr_Value = -2;
	}
	else
	{
		/* возвращаем частоты на место */
		if (var_Swap_F_TX == 1)
		{
			SCL_1_line_Control(1);
			si5351aSetFrequency(BFO_Get_Freq(), SI_CHIP_2);
			SCL_1_line_Control(0);
			si5351aSetFrequency(freq_si, SI_CHIP_1);
		}

		ABCD_Code &= (uint8_t)~PIN_PTT;
		SR_Write(ABCD_Code);

		func_Mode = FUNC_MODE_NORMAL;
		Band_Label_to_LCD();
	}
}

/* BFO для LSB/CWL на Si5351-2 */
static void Set_MODE_L(void)
{
	SCL_1_line_Control(1);
	_delay_ms(2);

	if (but_MODE == 0)      si5351aSetFrequency(freq_BFO_LSB, SI_CHIP_2);
	else if (but_MODE == 2) si5351aSetFrequency(freq_BFO_CWL, SI_CHIP_2);

	_delay_ms(2);
	SCL_1_line_Control(0);
}

/* BFO для USB/CWU на Si5351-2 */
static void Set_MODE_H(void)
{
	SCL_1_line_Control(1);
	_delay_ms(2);

	if (var_Conversion == 1)
	{
		if (but_MODE == 1)      si5351aSetFrequency(freq_BFO_USB, SI_CHIP_2);
		else if (but_MODE == 3) si5351aSetFrequency(freq_BFO_CWU, SI_CHIP_2);
	}
	else
	{
		/* в классике верхняя боковая формируется тем же BFO, что и нижняя */
		if (but_MODE == 1)      si5351aSetFrequency(freq_BFO_LSB, SI_CHIP_2);
		else if (but_MODE == 3) si5351aSetFrequency(freq_BFO_CWL, SI_CHIP_2);
	}

	_delay_ms(2);
	SCL_1_line_Control(0);
}

/*
 * Проверка возможности выбранного преобразования: в классике нельзя
 * работать выше нулевых биений.
 */
void Check_Conversion(void)
{
	if ((var_Conversion == 0) &&
	    (((freq_VFO <= freq_BFO_LSB) && (but_MODE == 1)) ||
	     ((freq_VFO <= freq_BFO_CWL) && (but_MODE == 3))))
	{
		if (but_MODE < 3) but_MODE++;
		else              but_MODE = 0;
	}

	Set_MODE();
}

/* установка моды: выходы CW, BFO и выходная частота */
void Set_MODE(void)
{
	LCD_set_pos(0, 1);

	switch (but_MODE)
	{
		case 0:		/* LSB */
			ABCD_Code &= (uint8_t)~PIN_CW;
			SR_Write(ABCD_Code);
			Set_MODE_L();
			LCD_send_str_P(PSTR("LSB"));
			break;

		case 1:		/* USB */
			ABCD_Code &= (uint8_t)~PIN_CW;
			SR_Write(ABCD_Code);
			Set_MODE_H();
			LCD_send_str_P(PSTR("USB"));
			break;

		case 2:		/* CWL */
			ABCD_Code |= PIN_CW;
			SR_Write(ABCD_Code);
			Set_MODE_L();
			LCD_send_str_P(PSTR("CWL"));
			break;

		default:	/* CWU */
			ABCD_Code |= PIN_CW;
			SR_Write(ABCD_Code);
			Set_MODE_H();
			LCD_send_str_P(PSTR("CWU"));
			break;
	}

	/* выходная частота VFO */
	Calc_Out_Freq_Si5351();
	si5351aSetFrequency(freq_si, SI_CHIP_1);
}

/* метка диапазона и ATT/PRE на LCD */
static void Band_Label_to_LCD(void)
{
	LCD_set_pos(0, 0);

	for (uint8_t i = 0; i < 5; i++)
		LCD_send_char(' ');

	LCD_set_pos(0, 0);
	LCD_send_str_P(band_Label[band_Num - 1]);

	/* восстанавливаем ATT/PRE текущего диапазона */
	but_ATT_PRE = att_pre[band_Num - 1];
	ATT_PRE_Refresh();
}

/*
 * Вывод частоты в формате 1'234.567 / 12'345.678 на LCD.
 * Работает для любой разрядности (в версии 2.3 при частоте ниже 1 МГц
 * выводился символ с кодом 0 — значок S-метра из CGRAM).
 */
void Freq_format_to_LCD(uint32_t freq, uint8_t col, uint8_t str)
{
	ultoa(freq, TempStr, 10);
	uint8_t len = (uint8_t)strlen(TempStr);
	uint8_t seps = 0;

	if (len >= 7) seps++;					/* разделитель тысяч */
	if (len >= 4) seps++;					/* десятичная точка */

	/* поле вывода — 10 знакомест, как в версии 2.x */
	LCD_set_pos(col, str);

	for (uint8_t i = (uint8_t)(len + seps); i < 10; i++)
		LCD_send_char(' ');

	for (uint8_t i = 0; i < len; i++)
	{
		uint8_t rest = (uint8_t)(len - i - 1);

		LCD_send_char((uint8_t)TempStr[i]);

		if (rest == 6)      LCD_send_char('\'');
		else if (rest == 3) LCD_send_char('.');
	}
}

/* вывод шага перестройки на LCD */
static void Step_Value_to_LCD(void)
{
	LCD_set_pos(0, 1);

	for (uint8_t i = 0; i < 8; i++)
		LCD_send_char(' ');

	LCD_set_pos(0, 1);

	if (set_Step < 1000)
	{
		ultoa(set_Step, TempStr, 10);
		LCD_send_str(TempStr);
		LCD_send_str_P(PSTR(" Hz"));
	}
	else
	{
		ultoa(set_Step / 1000, TempStr, 10);
		LCD_send_str(TempStr);
		LCD_send_str_P(PSTR(" kHz"));
	}
}

/* изменение шага перестройки: 1 - больше, 2 - меньше */
static void Change_STEP(uint8_t value)
{
	if (value == 1)
	{
		if (set_Step_index < STEP_COUNT - 1) set_Step_index++;
	}
	else if (value == 2)
	{
		if (set_Step_index > 0) set_Step_index--;
	}

	set_Step = pgm_read_dword(&step_Value[set_Step_index]);
	Step_Value_to_LCD();
}

/* вывод строки информации в первой строке LCD */
static void Setup_info_to_LCD(const char *infoStr)
{
	LCD_send_byte(0x01, 0);
	_delay_ms(5);
	LCD_set_pos(0, 0);
	LCD_send_str_P(infoStr);

	/* экран очищен — S-метр нужно будет перерисовать */
	old_S_metr_Value = -2;
}

/* настройка частот BFO: 1 - больше, 2 - меньше */
static void Set_BFO(uint8_t value)
{
	uint32_t *pFreq;

	switch (func_Mode)
	{
		case FUNC_MODE_SET_BFO_LSB: pFreq = &freq_BFO_LSB; break;
		case FUNC_MODE_SET_BFO_USB: pFreq = &freq_BFO_USB; break;
		case FUNC_MODE_SET_BFO_CWL: pFreq = &freq_BFO_CWL; break;
		case FUNC_MODE_SET_BFO_CWU: pFreq = &freq_BFO_CWU; break;
		default: return;
	}

	*pFreq = Step_Freq(*pFreq, value, FREQ_BFO_MIN, FREQ_VFO_MAX);

	Freq_format_to_LCD(*pFreq, 6, 1);
}

/*
 * Калибровка опоры Si5351. На выход выводится номинальная частота 25 МГц
 * (измеряется частотомером), а поправка хранится в xtall_FREQ_1/2.
 */
static void Set_XTALL(uint8_t value)
{
	uint32_t *pFreq;
	uint32_t nominal;
	uint8_t chip;

	if (func_Mode == FUNC_MODE_SET_XTALL_1)
	{
		pFreq = &xtall_FREQ_1;
		nominal = FREQ_XTALL_1_DEF;
		chip = SI_CHIP_1;
	}
	else if (func_Mode == FUNC_MODE_SET_XTALL_2)
	{
		pFreq = &xtall_FREQ_2;
		nominal = FREQ_XTALL_2_DEF;
		chip = SI_CHIP_2;
	}
	else return;

	/* раньше здесь проверялись границы VFO (1...30 МГц) — для опоры это неверно */
	*pFreq = Step_Freq(*pFreq, value, FREQ_XTALL_MIN, FREQ_XTALL_MAX);

	/* выводим номинальную частоту для измерения */
	si5351aSetFrequency(nominal, chip);

	Freq_format_to_LCD(*pFreq, 6, 1);
}

/* разрешение/запрещение диапазона в настройках */
static void Set_use_BAND(uint8_t value)
{
	LCD_set_pos(0, 1);

	for (uint8_t i = 0; i < 9; i++)
		LCD_send_char(' ');

	LCD_set_pos(0, 1);
	LCD_send_str_P(band_Label[bandDataNum]);

	if (value) LCD_send_str_P(PSTR(": on"));
	else       LCD_send_str_P(PSTR(": off"));

	band_use[bandDataNum] = value;
	eeprom_update_byte((uint8_t*)(EE_ADDR_BAND_USE + bandDataNum), value);
}

/* вывод тока драйвера CLK0 и обновление выхода Si5351 */
static void DrvST_to_LCD(uint8_t value)
{
	LCD_set_pos(0, 1);

	switch (value)
	{
		case 0:  LCD_send_str_P(PSTR("2 mA")); break;
		case 1:  LCD_send_str_P(PSTR("4 mA")); break;
		case 2:  LCD_send_str_P(PSTR("6 mA")); break;
		default: LCD_send_str_P(PSTR("8 mA")); break;
	}

	if (func_Mode == FUNC_MODE_SET_DRV_ST_1)
		si5351aSetFrequency(freq_si, SI_CHIP_1);
	else if (func_Mode == FUNC_MODE_SET_DRV_ST_2)
		si5351aSetFrequency(freq_BFO_LSB, SI_CHIP_2);
}

/* изменение тока драйвера CLK0: 0 - меньше, 1 - больше */
static void Set_DRV_ST(uint8_t value)
{
	uint8_t *pDsc;

	if (func_Mode == FUNC_MODE_SET_DRV_ST_1)      pDsc = &siDSC_1;
	else if (func_Mode == FUNC_MODE_SET_DRV_ST_2) pDsc = &siDSC_2;
	else return;

	/* раньше здесь было (*pDsc)-- с проверкой < 0 для uint8_t — не работала */
	if (value == 0)
	{
		if (*pDsc > 0) (*pDsc)--;
	}
	else if (value == 1)
	{
		if (*pDsc < 3) (*pDsc)++;
	}

	DrvST_to_LCD(*pDsc);
}

/* вариант преобразования: 2 - только показать текущий */
static void Set_Conversion(uint8_t value)
{
	LCD_set_pos(0, 1);

	if (value != 2) var_Conversion = value;

	if (var_Conversion) LCD_send_str_P(PSTR("always up"));
	else                LCD_send_str_P(PSTR("classic  "));
}

/* смена частот VFO/BFO при TX: 2 - только показать текущий */
static void Set_Swap_F_TX(uint8_t value)
{
	LCD_set_pos(0, 1);

	if (value != 2) var_Swap_F_TX = value;

	if (var_Swap_F_TX) LCD_send_str_P(PSTR("on "));
	else               LCD_send_str_P(PSTR("off"));
}

/*--- установки синтезатора по CAT (команды приложения) -------------------*/

/* частота BFO: 0 - LSB, 1 - USB, 2 - CWL, 3 - CWU */
void CAT_Set_BFO(uint8_t index, uint32_t freq)
{
	uint32_t *pFreq;
	uint16_t addr;

	switch (index)
	{
		case 0: pFreq = &freq_BFO_LSB; addr = EE_ADDR_BFO_LSB; break;
		case 1: pFreq = &freq_BFO_USB; addr = EE_ADDR_BFO_USB; break;
		case 2: pFreq = &freq_BFO_CWL; addr = EE_ADDR_BFO_CWL; break;
		case 3: pFreq = &freq_BFO_CWU; addr = EE_ADDR_BFO_CWU; break;
		default: return;
	}

	*pFreq = Clamp_Freq(freq, FREQ_BFO_MIN, FREQ_VFO_MAX);
	eeprom_update_dword((uint32_t*)addr, *pFreq);

	/* пересчитать выходную частоту и заново запрограммировать Si5351 */
	Set_MODE();
}

/* частота опоры: 0 - Si5351-1, 1 - Si5351-2 */
void CAT_Set_XTALL(uint8_t index, uint32_t freq)
{
	if (index == 0)
	{
		xtall_FREQ_1 = Clamp_Freq(freq, FREQ_XTALL_MIN, FREQ_XTALL_MAX);
		eeprom_update_dword((uint32_t*)EE_ADDR_XTALL_1, xtall_FREQ_1);
	}
	else
	{
		xtall_FREQ_2 = Clamp_Freq(freq, FREQ_XTALL_MIN, FREQ_XTALL_MAX);
		eeprom_update_dword((uint32_t*)EE_ADDR_XTALL_2, xtall_FREQ_2);
	}

	Set_MODE();
}

/* шаг перестройки: индекс массива step_Value */
void CAT_Set_STEP(uint8_t index)
{
	if (index >= STEP_COUNT) return;

	set_Step_index = index;
	set_Step = pgm_read_dword(&step_Value[index]);
	eeprom_update_byte((uint8_t*)EE_ADDR_STEP, index);
}

/* ток драйвера CLK0 обеих Si5351: 0 - 2 мА ... 3 - 8 мА */
void CAT_Set_DRV(uint8_t drive1, uint8_t drive2)
{
	if (drive1 > 3) drive1 = 3;
	if (drive2 > 3) drive2 = 3;

	siDSC_1 = drive1;
	siDSC_2 = drive2;

	eeprom_update_byte((uint8_t*)EE_ADDR_DRV_ST_1, siDSC_1);
	eeprom_update_byte((uint8_t*)EE_ADDR_DRV_ST_2, siDSC_2);

	Set_MODE();
}

/* вариант преобразования: 0 - классика, 1 - всегда вверх */
void CAT_Set_CONVERSION(uint8_t value)
{
	var_Conversion = value ? 1 : 0;
	eeprom_update_byte((uint8_t*)EE_ADDR_CONV, var_Conversion);

	Set_MODE();
}

/* смена частот VFO/BFO при TX */
void CAT_Set_SWAP(uint8_t value)
{
	var_Swap_F_TX = value ? 1 : 0;
	eeprom_update_byte((uint8_t*)EE_ADDR_SWAP_TX, var_Swap_F_TX);
}

/* включение диапазонов: 9 значений 0/1 */
void CAT_Set_BAND_USE(const uint8_t *mask)
{
	uint8_t any = 0;

	for (uint8_t i = 0; i < BANDS_COUNT; i++)
	{
		band_use[i] = mask[i] ? 1 : 0;
		any |= band_use[i];

		eeprom_update_byte((uint8_t*)(EE_ADDR_BAND_USE + i), band_use[i]);
	}

	/* хотя бы один диапазон должен остаться включённым */
	if (!any)
	{
		band_use[band_Num - 1] = 1;
		eeprom_update_byte((uint8_t*)(EE_ADDR_BAND_USE + band_Num - 1), 1);
	}
}

/* ATT/PRE по диапазонам: 9 значений 0/1/2 */
void CAT_Set_ATT_PRE(const uint8_t *values)
{
	for (uint8_t i = 0; i < BANDS_COUNT; i++)
	{
		att_pre[i] = (values[i] > 2) ? 0 : values[i];

		eeprom_update_byte((uint8_t*)(EE_ADDR_ATT_PRE + i), att_pre[i]);
	}

	but_ATT_PRE = att_pre[band_Num - 1];
	ATT_PRE_Refresh();
}

/* порог S-метра: индекс 0...6, значение 0...255 */
void CAT_Set_SMETER(uint8_t index, uint8_t value)
{
	if (index >= SMETR_CAL_COUNT) return;

	smetr_cal[index] = value;
	eeprom_update_byte((uint8_t*)(EE_ADDR_SMETR_CAL + index), value);
}

/* выбор первого включённого диапазона */
static void Select_First_Enabled_Band(void){
	band_Num = BAND_160m;

	for (uint8_t i = 0; i < BANDS_COUNT; i++)
	{
		if (band_use[band_Num - 1] == 1) return;
		band_Num++;
	}

	/* ни один не включён — включаем 160m */
	band_Num = BAND_160m;
	band_use[0] = 1;
	eeprom_update_byte((uint8_t*)EE_ADDR_BAND_USE, 1);
}

/* проверка и смена диапазона по текущей частоте */
void Check_BAND(void)
{
	uint8_t old_band_num = band_Num;
	uint8_t code;

	if (freq_VFO <= BAND_1_MAX)      band_Num = BAND_160m;
	else if (freq_VFO <= BAND_2_MAX) band_Num = BAND_80m;
	else if (freq_VFO <= BAND_3_MAX) band_Num = BAND_40m;
	else if (freq_VFO <= BAND_4_MAX) band_Num = BAND_30m;
	else if (freq_VFO <= BAND_5_MAX) band_Num = BAND_20m;
	else if (freq_VFO <= BAND_6_MAX) band_Num = BAND_17m;
	else if (freq_VFO <= BAND_7_MAX) band_Num = BAND_15m;
	else if (freq_VFO <= BAND_8_MAX) band_Num = BAND_12m;
	else if (freq_VFO <= FREQ_VFO_MAX) band_Num = BAND_10m;

	if (old_band_num != band_Num)
	{
		/* сохраняем номер диапазона (только при реальном изменении) */
		eeprom_update_byte((uint8_t*)EE_ADDR_BAND, band_Num);

		/* восстанавливаем ATT/PRE этого диапазона до формирования кода */
		but_ATT_PRE = att_pre[band_Num - 1];
	}

	/* код диапазона + ATT/PRE + CW, бит PTT сохраняем */
	code = (uint8_t)(ABCD_Code & PIN_PTT);
	if (but_ATT_PRE == 1)      code |= PIN_ATT;
	else if (but_ATT_PRE == 2) code |= PIN_PRE;
	if ((but_MODE == 2) || (but_MODE == 3)) code |= PIN_CW;
	code |= (uint8_t)(band_Num - 1);

	SR_Write(code);

	if (old_band_num != band_Num)
		Band_Label_to_LCD();

	Calc_Out_Freq_Si5351();
	si5351aSetFrequency(freq_si, SI_CHIP_1);
}

/* перестройка VFO: 1 - вверх, 2 - вниз, 0 - только обновить экран */
static void Change_VFO(uint8_t value)
{
	uint32_t oldFreqVFO = freq_VFO;

	if (value == 1)      freq_VFO += set_Step;
	else if (value == 2) freq_VFO -= set_Step;

	if ((freq_VFO >= FREQ_VFO_MIN) && (freq_VFO <= FREQ_VFO_MAX))
	{
		Check_BAND();
		Freq_format_to_LCD(freq_VFO, 6, 0);
		timerCountSaveBandData = 0;
	}
	else
	{
		freq_VFO = oldFreqVFO;
	}
}

/*
 * Переход на следующий/предыдущий включённый диапазон.
 * Раньше здесь был while(), который мог не завершиться, если все диапазоны
 * выключены в настройках; теперь не более девяти шагов и принудительное
 * включение текущего диапазона.
 */
void Change_Band(int8_t dir)
{
	for (uint8_t i = 0; i < BANDS_COUNT; i++)
	{
		if (dir > 0)
		{
			band_Num++;
			if (band_Num > BANDS_COUNT) band_Num = BAND_160m;
		}
		else
		{
			band_Num--;
			if (band_Num < 1) band_Num = BAND_10m;
		}

		if (band_use[band_Num - 1] == 1) break;
	}

	if (band_use[band_Num - 1] != 1)
	{
		band_use[band_Num - 1] = 1;
		eeprom_update_byte((uint8_t*)(EE_ADDR_BAND_USE + band_Num - 1), 1);
	}

	eeprom_update_byte((uint8_t*)EE_ADDR_BAND, band_Num);
	Set_BAND();
}

/* переход на диапазон: последняя частота и «правильная» мода */
void Set_BAND(void)
{
	freq_VFO = band_last_F_BUFF[band_Num - 1];

	/* ниже 8 МГц — LSB, выше — USB */
	but_MODE = (freq_VFO <= BAND_3_MAX) ? 0 : 1;

	Set_MODE();
	Change_VFO(0);
	Band_Label_to_LCD();
}

/* сохранение частоты текущего диапазона в EEPROM */
static void BandDataSaved(void)
{
	band_last_F_BUFF[band_Num - 1] = freq_VFO;
	eeprom_update_dword((uint32_t*)(EE_ADDR_BAND_FREQ + 4 * (band_Num - 1)), freq_VFO);
}

/*--- обработка кнопок ----------------------------------------------------*/

static void Button_PAD(void)
{
	/*
	 * Кнопки подключены к одному входу ADC0 через резистивный делитель,
	 * поэтому одновременно нажата только одна. Прерывание АЦП определяет
	 * номер кнопки (butBuf), таймер 1 считает время удержания
	 * (but_Count_Pressed).
	 *
	 * Действия делятся на два вида:
	 *   - по уровню (пока кнопка нажата): ATT/PRE, MODE, PTT;
	 *   - по отпусканию (по длительности удержания): FUNC (короткое /
	 *     1...2 с — меню).
	 */

	/*--- кнопка нажата ---------------------------------------------------*/
	if (butBuf != BUT_NULL)
	{
		if (butBuf == BUT_FUNC)
		{
			butPress_F = 1;
		}

		if (butBuf == BUT_ATT_PRE)
		{
			butPress_F = 1;

			if ((func_Mode == FUNC_MODE_NORMAL) && (button_Action_Done == 0) &&
			    Button_Hold_At_Least(BTN_TAP_MIN_MS))
			{
				button_Action_Done = 1;

				ATT_PRE_Toggle();
			}
		}

		if (butBuf == BUT_MODE)
		{
			butPress_F = 1;

			if ((func_Mode == FUNC_MODE_NORMAL) && (button_Action_Done == 0) &&
			    Button_Hold_At_Least(BTN_TAP_MIN_MS))
			{
				button_Action_Done = 1;

				if (but_MODE < 3) but_MODE++;
				else              but_MODE = 0;

				Check_Conversion();
			}
		}

		if (butBuf == BUT_PTT)
		{
			if (func_Mode == FUNC_MODE_TX)
			{
				butPress_F = 0;
				but_Count_Pressed = 0;
			}
			else if (func_Mode == FUNC_MODE_NORMAL)
			{
				butPress_F = 1;
			}

			if ((func_Mode == FUNC_MODE_NORMAL) && (button_Action_Done == 0) &&
			    Button_Hold_At_Least(BTN_PTT_HOLD_MIN_MS))
			{
				button_Action_Done = 1;
				PTT_ON(1);
			}
		}

		return;
	}

	/*--- кнопки отпущены -------------------------------------------------*/
	button_Action_Done = 0;

	if ((func_Mode != FUNC_MODE_TX) && (butPressFUNC == 1))
	{
		uint16_t held = but_Count_Pressed;

		/* удержание от 5 с в основном режиме — вход в настройки (BFO-LSB) */
		if ((held >= MS_TO_TICKS(FUNC_SETUP_MIN_MS)) && (func_Mode == FUNC_MODE_NORMAL))
		{
			modeSetup = 2;
			set_Step_F = 0;
			func_Mode = FUNC_MODE_SET_BFO_LSB;
			Setup_info_to_LCD(PSTR("Freq BFO-LSB"));
			Freq_format_to_LCD(freq_BFO_LSB, 6, 1);
		}
		else
		/* удержание 1...5 с — выбор шага перестройки */
		if ((held >= MS_TO_TICKS(FUNC_STEP_MIN_MS)) &&
		    ((func_Mode == FUNC_MODE_NORMAL) || (func_Mode == FUNC_MODE_SET_BFO_LSB) ||
		     (func_Mode == FUNC_MODE_SET_BFO_USB) || (func_Mode == FUNC_MODE_SET_BFO_CWL) ||
		     (func_Mode == FUNC_MODE_SET_BFO_CWU) || (func_Mode == FUNC_MODE_SET_XTALL_1) ||
		     (func_Mode == FUNC_MODE_SET_XTALL_2)))
		{
			modeSetup = 1;

			switch (func_Mode)
			{
				case FUNC_MODE_NORMAL:      set_Step_F = 1; break;
				case FUNC_MODE_SET_BFO_LSB: set_Step_F = 2; break;
				case FUNC_MODE_SET_BFO_USB: set_Step_F = 3; break;
				case FUNC_MODE_SET_BFO_CWL: set_Step_F = 4; break;
				case FUNC_MODE_SET_BFO_CWU: set_Step_F = 5; break;
				case FUNC_MODE_SET_XTALL_1: set_Step_F = 6; break;
				default:                    set_Step_F = 7; break;	/* XTALL_2 */
			}

			func_Mode = FUNC_MODE_SET_STEP;
			Setup_info_to_LCD(PSTR("Select step"));
			Step_Value_to_LCD();
		}
		else
		/* короткое нажатие — смена диапазона или следующий пункт настроек */
		if (held < MS_TO_TICKS(FUNC_SHORT_MAX_MS))
		{
			/* короткое нажатие в основном режиме — следующий диапазон */
			if ((func_Mode == FUNC_MODE_NORMAL) && (modeSetup == 0))
			{
				Change_Band(1);
			}

		/* короткое нажатие после выбора шага — следующий пункт настроек */
		if ((set_Step_F != 0) &&
		    ((func_Mode == FUNC_MODE_SET_STEP) || (func_Mode == FUNC_MODE_SET_BFO_LSB) ||
		     (func_Mode == FUNC_MODE_SET_BFO_USB) || (func_Mode == FUNC_MODE_SET_BFO_CWL) ||
		     (func_Mode == FUNC_MODE_SET_BFO_CWU) || (func_Mode == FUNC_MODE_SET_XTALL_1) ||
		     (func_Mode == FUNC_MODE_SET_XTALL_2)))
		{
			/* сохраняем индекс шага */
			eeprom_update_byte((uint8_t*)EE_ADDR_STEP, set_Step_index);

			switch (set_Step_F)
			{
				case 1:		/* возврат в основной режим */
					func_Mode = FUNC_MODE_NORMAL;
					LCD_send_byte(0x01, 0);
					_delay_ms(5);
					Change_VFO(0);
					Band_Label_to_LCD();
					Set_MODE();
					modeSetup = 0;
					old_S_metr_Value = -2;
					break;

				case 2:		/* BFO_LSB */
					func_Mode = FUNC_MODE_SET_BFO_LSB;
					Setup_info_to_LCD(PSTR("Freq BFO-LSB"));
					Freq_format_to_LCD(freq_BFO_LSB, 6, 1);
					modeSetup = 2;
					break;

				case 3:		/* BFO_USB */
					func_Mode = FUNC_MODE_SET_BFO_USB;
					Setup_info_to_LCD(PSTR("Freq BFO-USB"));
					Freq_format_to_LCD(freq_BFO_USB, 6, 1);
					modeSetup = 3;
					break;

				case 4:		/* BFO_CWL */
					func_Mode = FUNC_MODE_SET_BFO_CWL;
					Setup_info_to_LCD(PSTR("Freq BFO-CWL"));
					Freq_format_to_LCD(freq_BFO_CWL, 6, 1);
					modeSetup = 4;
					break;

				case 5:		/* BFO_CWU */
					func_Mode = FUNC_MODE_SET_BFO_CWU;
					Setup_info_to_LCD(PSTR("Freq BFO-CWU"));
					Freq_format_to_LCD(freq_BFO_CWU, 6, 1);
					modeSetup = 5;
					break;

				case 6:		/* калибровка XTALL_1 */
					func_Mode = FUNC_MODE_SET_XTALL_1;
					Setup_info_to_LCD(PSTR("Freq XTALL-1"));
					Set_XTALL(0);
					modeSetup = 6;
					break;

				default:	/* калибровка XTALL_2 */
					func_Mode = FUNC_MODE_SET_XTALL_2;
					SCL_1_line_Control(1);
					Setup_info_to_LCD(PSTR("Freq XTALL-2"));
					Set_XTALL(0);
					modeSetup = 7;
					break;
			}

			set_Step_F = 0;
			but_Count_Pressed = 0;
		}

		/* короткое нажатие — переход к следующему пункту настроек */
		if ((set_Step_F == 0) && (modeSetup >= 2) && (modeSetup <= 12))
		{
			switch (func_Mode)
			{
				case FUNC_MODE_SET_BFO_LSB:
					eeprom_update_dword((uint32_t*)EE_ADDR_BFO_LSB, freq_BFO_LSB);
					func_Mode = FUNC_MODE_SET_BFO_USB;
					Setup_info_to_LCD(PSTR("Freq BFO-USB"));
					Freq_format_to_LCD(freq_BFO_USB, 6, 1);
					modeSetup = 3;
					break;

				case FUNC_MODE_SET_BFO_USB:
					eeprom_update_dword((uint32_t*)EE_ADDR_BFO_USB, freq_BFO_USB);
					func_Mode = FUNC_MODE_SET_BFO_CWL;
					Setup_info_to_LCD(PSTR("Freq BFO-CWL"));
					Freq_format_to_LCD(freq_BFO_CWL, 6, 1);
					modeSetup = 4;
					break;

				case FUNC_MODE_SET_BFO_CWL:
					eeprom_update_dword((uint32_t*)EE_ADDR_BFO_CWL, freq_BFO_CWL);
					func_Mode = FUNC_MODE_SET_BFO_CWU;
					Setup_info_to_LCD(PSTR("Freq BFO-CWU"));
					Freq_format_to_LCD(freq_BFO_CWU, 6, 1);
					modeSetup = 5;
					break;

				case FUNC_MODE_SET_BFO_CWU:
					eeprom_update_dword((uint32_t*)EE_ADDR_BFO_CWU, freq_BFO_CWU);
					func_Mode = FUNC_MODE_SET_XTALL_1;
					Setup_info_to_LCD(PSTR("Freq XTALL-1"));
					Set_XTALL(0);
					modeSetup = 6;
					break;

				case FUNC_MODE_SET_XTALL_1:
					eeprom_update_dword((uint32_t*)EE_ADDR_XTALL_1, xtall_FREQ_1);
					func_Mode = FUNC_MODE_SET_XTALL_2;
					SCL_1_line_Control(1);
					Setup_info_to_LCD(PSTR("Freq XTALL-2"));
					Set_XTALL(0);
					modeSetup = 7;
					break;

				case FUNC_MODE_SET_XTALL_2:
					eeprom_update_dword((uint32_t*)EE_ADDR_XTALL_2, xtall_FREQ_2);
					si5351aSetFrequency(freq_BFO_LSB, SI_CHIP_2);
					SCL_1_line_Control(0);
					si5351aSetFrequency(freq_si, SI_CHIP_1);
					func_Mode = FUNC_MODE_SET_DRV_ST_1;
					Setup_info_to_LCD(PSTR("DrvSt Si-1"));
					DrvST_to_LCD(siDSC_1);
					modeSetup = 8;
					break;

				case FUNC_MODE_SET_DRV_ST_1:
					eeprom_update_byte((uint8_t*)EE_ADDR_DRV_ST_1, siDSC_1);
					func_Mode = FUNC_MODE_SET_DRV_ST_2;
					SCL_1_line_Control(1);
					si5351aSetFrequency(freq_BFO_LSB, SI_CHIP_2);
					Setup_info_to_LCD(PSTR("DrvSt Si-2"));
					DrvST_to_LCD(siDSC_2);
					modeSetup = 9;
					break;

				case FUNC_MODE_SET_DRV_ST_2:
					eeprom_update_byte((uint8_t*)EE_ADDR_DRV_ST_2, siDSC_2);
					SCL_1_line_Control(0);
					si5351aSetFrequency(freq_si, SI_CHIP_1);
					func_Mode = FUNC_MODE_SET_CONV;
					Setup_info_to_LCD(PSTR("Set conversion"));
					Set_Conversion(2);
					modeSetup = 10;
					break;

				case FUNC_MODE_SET_CONV:
					eeprom_update_byte((uint8_t*)EE_ADDR_CONV, var_Conversion);
					func_Mode = FUNC_MODE_SET_SWP_F_TX;
					Setup_info_to_LCD(PSTR("Swap freq on TX"));
					Set_Swap_F_TX(2);
					modeSetup = 11;
					break;

				case FUNC_MODE_SET_SWP_F_TX:
					eeprom_update_byte((uint8_t*)EE_ADDR_SWAP_TX, var_Swap_F_TX);
					func_Mode = FUNC_MODE_SET_BAND;
					Setup_info_to_LCD(PSTR("Use bands"));
					bandDataNum = 0;
					Set_use_BAND(band_use[bandDataNum]);
					modeSetup = 12;
					break;

				case FUNC_MODE_SET_BAND:
					if (bandDataNum < BANDS_COUNT - 1)
					{
						bandDataNum++;
						Set_use_BAND(band_use[bandDataNum]);
					}
					else
					{
						/* конец настроек */
						func_Mode = FUNC_MODE_NORMAL;
						LCD_send_byte(0x01, 0);
						_delay_ms(5);				/* очистка экрана занимает 1.52 мс */
						modeSetup = 0;

						/* диапазон оставляем текущим; если его выключили — первый включённый */
						if (band_use[band_Num - 1] != 1) Select_First_Enabled_Band();

						eeprom_update_byte((uint8_t*)EE_ADDR_BAND, band_Num);
						Set_BAND();
						old_S_metr_Value = -2;
					}
					break;

				default:
					break;
			}
		}
		}
	}

	butPressFUNC = 0;
	butPress_F = 0;

	if ((func_Mode == FUNC_MODE_TX) && (ptt_cat_ON_F == 0))
		PTT_ON(0);

	but_Count_Pressed = 0;
}

/*--- обработка энкодера ---------------------------------------------------*/

static void Encoder_Up(void)
{
	switch (func_Mode)
	{
		case FUNC_MODE_NORMAL:       Change_VFO(1); break;
		case FUNC_MODE_SET_STEP:     Change_STEP(1); break;
		case FUNC_MODE_SET_BFO_LSB:
		case FUNC_MODE_SET_BFO_USB:
		case FUNC_MODE_SET_BFO_CWL:
		case FUNC_MODE_SET_BFO_CWU:  Set_BFO(1); break;
		case FUNC_MODE_SET_XTALL_1:
		case FUNC_MODE_SET_XTALL_2:  Set_XTALL(1); break;
		case FUNC_MODE_SET_BAND:     Set_use_BAND(1); break;
		case FUNC_MODE_SET_DRV_ST_1:
		case FUNC_MODE_SET_DRV_ST_2: Set_DRV_ST(1); break;
		case FUNC_MODE_SET_CONV:     Set_Conversion(1); break;
		case FUNC_MODE_SET_SWP_F_TX: Set_Swap_F_TX(1); break;
		default: break;
	}
}

static void Encoder_Down(void)
{
	switch (func_Mode)
	{
		case FUNC_MODE_NORMAL:       Change_VFO(2); break;
		case FUNC_MODE_SET_STEP:     Change_STEP(2); break;
		case FUNC_MODE_SET_BFO_LSB:
		case FUNC_MODE_SET_BFO_USB:
		case FUNC_MODE_SET_BFO_CWL:
		case FUNC_MODE_SET_BFO_CWU:  Set_BFO(2); break;
		case FUNC_MODE_SET_XTALL_1:
		case FUNC_MODE_SET_XTALL_2:  Set_XTALL(2); break;
		case FUNC_MODE_SET_BAND:     Set_use_BAND(0); break;
		case FUNC_MODE_SET_DRV_ST_1:
		case FUNC_MODE_SET_DRV_ST_2: Set_DRV_ST(0); break;
		case FUNC_MODE_SET_CONV:     Set_Conversion(0); break;
		case FUNC_MODE_SET_SWP_F_TX: Set_Swap_F_TX(0); break;
		default: break;
	}
}

/*--- таймеры, АЦП, прерывания -------------------------------------------*/

static void TIMER1_Init(void)
{
	TCCR1A = 0x00;				/* normal mode */
	TCCR1B |= (1 << CS11);		/* делитель 8 */
	TCNT1H = 0x00;
	TCNT1L = 0x00;
	OCR1AH = 0x03;				/* период 1000 тактов — 320 мкс */
	OCR1AL = 0xE8;
}

static void ADC_Init(void)
{
	/* опора AVcc, выравнивание влево, вход ADC0 */
	ADMUX = (0 << REFS1) | (1 << REFS0) | (1 << ADLAR);

	/* включаем АЦП, прерывание по завершении, тактовая CLK/128 */
	ADCSRA = (1 << ADEN) | (0 << ADSC) | (0 << ADATE) | (1 << ADIE) |
	         (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

ISR(ADC_vect)
{
	static uint8_t  lastButtonPressed = BUT_NULL;
	static uint16_t compareCount = 0;
	uint8_t data_ADC_0;

	switch (ADMUX)
	{
		case 0x60:		/* кнопки на ADC0 */
			data_ADC_0 = ADCH;

			if ((data_ADC_0 > 155) && (data_ADC_0 < 165))       butBuf = BUT_MODE;
			else if ((data_ADC_0 > 134) && (data_ADC_0 < 146))  butBuf = BUT_PTT;
			else if ((data_ADC_0 > 95) && (data_ADC_0 < 105))   butBuf = BUT_ATT_PRE;
			else if (data_ADC_0 < 60)                          butBuf = BUT_FUNC;
			else                                               butBuf = BUT_NULL;

			if (butBuf != BUT_NULL)
			{
				if (butBuf == lastButtonPressed)
				{
					if (compareCount > MS_TO_TICKS(BTN_DEBOUNCE_MS))
					{
						/* кнопка удерживается — взводим флаг FUNC */
						if (lastButtonPressed == BUT_FUNC) butPressFUNC = 1;
						lastButtonPressed = butBuf;
					}
					else
					{
						compareCount++;
					}
				}
				else
				{
					lastButtonPressed = butBuf;
					compareCount = 0;
				}
			}
			else
			{
				compareCount = 0;
				lastButtonPressed = BUT_NULL;
			}

			/*
			 * Дальше меряем S-метр: канал ADC1, опора AVcc, выравнивание
			 * влево (0x61).
			 */
			ADMUX = 0x61;
			break;

		case 0x61:		/* S-метр на ADC1 */
		{
			/*
			 * Берём все 10 бит: сигнал S-метра укладывается в 0...0,7 В, а
			 * шкала АЦП — 0...5 В, поэтому 8 бит давали всего 0...33 отсчёта.
			 * Пересчитываем 10 бит в 0...255 для диапазона 0...1,2 В
			 * (245 = 1,2 В в 10-битной шкале).
			 */
			uint8_t  lo = ADCL;
			uint8_t  hi = ADCH;

			uint16_t raw = (uint16_t)(((uint16_t)hi << 2) | (lo >> 6));
			uint32_t scaled = ((uint32_t)raw * 255UL + 122UL) / 245UL;

			if (scaled > 255UL) scaled = 255UL;

			data_ADC_1 = (uint8_t)scaled;

			/*
			 * Сглаживание прямо в прерывании: показания не «дышат», а значение
			 * для CAT (SM;) и для кубиков одно и то же.
			 */
			adc1_Filt -= (uint16_t)(adc1_Filt >> SMETR_FILTER_SHIFT);
			adc1_Filt += data_ADC_1;

			data_ADC_1_filt = (uint8_t)((adc1_Filt + (1u << (SMETR_FILTER_SHIFT - 1))) >> SMETR_FILTER_SHIFT);

			adc1_Sample_New = 1;
			ADMUX = 0x60;
			break;
		}

		default:
			ADMUX = 0x60;
			break;
	}

	ADCSRA |= (1 << ADSC);
}

ISR(TIMER1_COMPA_vect)
{
	next_state = (uint8_t)(PIND & ENCODER_MASK);

	if (next_state != prev_state)
	{
		switch (prev_state)
		{
			case 8:  if (next_state == 12) up_state++; else if (next_state == 0) down_state++; break;
			case 0:  if (next_state == 8)  up_state++; else if (next_state == 4) down_state++; break;
			case 4:  if (next_state == 0)  up_state++; else if (next_state == 12) down_state++; break;
			case 12: if (next_state == 4)  up_state++; else if (next_state == 8) down_state++; break;
			default: break;
		}

		prev_state = next_state;
	}

	TCNT1H = 0x00;
	TCNT1L = 0x00;

	/* счётчик удержания кнопки (с насыщением, без переполнения) */
	if (butPress_F == 1)
	{
		if (but_Count_Pressed < BTN_COUNT_MAX) but_Count_Pressed++;
	}

	/*
	 * Сохранение частоты диапазона. Раньше запись EEPROM выполнялась прямо в
	 * прерывании (~14 мс без обработки USART), теперь — флаг для main().
	 */
	if (timerCountSaveBandData != SAVE_BAND_DATA_IDLE)
	{
		timerCountSaveBandData++;

		if (timerCountSaveBandData >= SAVE_BAND_DATA_TICKS)
		{
			timerCountSaveBandData = SAVE_BAND_DATA_IDLE;
			flag_Save_BandData = 1;
		}
	}
}

/*----------------------------- main --------------------------------------*/
int main(void)
{
	/* порт D: PD2/PD3 — входы энкодера с подтяжкой, остальные — выходы */
	DDRD  = 0xFB;
	PORTD = 0x4C;

	DDRB  = 0xFF;
	PORTB = 0x00;

	/* PC3 — управление мультиплексором SCL1, это выход (раньше работал
	 * как вход с подтяжкой: высокий уровень был «слабым», через резистор) */
	DDRC |= (1 << SW_I2C);

	ADC_Init();
	TIMER1_Init();

	sei();

	Read_Setup_EEPROM();
	i2cInit();
	USART_Init(MYUBRR);

	/* CLK1/CLK2 не используются — гасим их на ОБЕИХ Si5351
	 * (мультиплексор переключаем вручную: команда уходит только в выбранную) */
	SCL_1_line_Control(0);					/* Si5351-1 (VFO) */
	si5351aOutputOff(0);

	SCL_1_line_Control(1);					/* Si5351-2 (BFO) */
	si5351aOutputOff(0);

	SCL_1_line_Control(0);					/* обратно на Si5351-1 */

	/* PTT выключен */
	SR_Write(ABCD_Code & (uint8_t)~PIN_PTT);

	LCD_ini();

	Set_BAND();
	Set_MODE();

	TIMSK1 |= (1 << OCIE1A);				/* прерывание таймера 1 */
	UCSR0B |= (1 << RXCIE0);				/* прерывание приёма USART */
	ADCSRA |= (1 << ADSC);					/* запускаем АЦП */

	CAT_IF_Send();

	while (1)
	{
		handlerTXUSART();
		handlerRXUSART();

		if (flag_Save_BandData)
		{
			flag_Save_BandData = 0;
			BandDataSaved();
		}

		/*
		 * Энкодер. Счётчики сбрасываются всегда, чтобы после TX или меню
		 * не было «лишнего» шага перестройки.
		 */
		if (up_state >= 8)
		{
			up_state = 0;
			if (butBuf == BUT_NULL) Encoder_Up();
		}

		if (down_state >= 8)
		{
			down_state = 0;
			if (butBuf == BUT_NULL) Encoder_Down();
		}

		Button_PAD();

		if ((func_Mode == FUNC_MODE_NORMAL) && (butBuf == BUT_NULL))
			S_METR();
	}
}
