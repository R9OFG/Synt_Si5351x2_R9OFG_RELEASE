﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * Lcd_1602.h
 *
 * Author: R9OFG (ex R0AEK)
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#ifndef LCD_1602_H_
#define LCD_1602_H_

#include <inttypes.h>
#include <avr/io.h>
#include <avr/pgmspace.h>

/*--- управляющие линии LCD1602 -------------------------------------------*/
#define E_1		PORTB |= (1 << PB0)			/* стробирующий сигнал E = 1, вывод PB0 */
#define E_0		PORTB &= ~(1 << PB0)		/* стробирующий сигнал E = 0 */
#define RS_1	PORTD |= (1 << PD7)			/* RS = 1 (данные), вывод PD7 */
#define RS_0	PORTD &= ~(1 << PD7)		/* RS = 0 (команда) */

void LCD_send_half_byte(uint8_t c);
void LCD_send_byte(uint8_t c, uint8_t mode);
void LCD_define_char(const uint8_t *pc, uint8_t char_code);
void LCD_send_char(uint8_t c);
void LCD_send_str(const char *str);
void LCD_send_str_P(const char *str);
void LCD_send_str_delay_P(const char *str);
void LCD_set_pos(uint8_t x, uint8_t y);
void LCD_ini(void);

#endif /* LCD_1602_H_ */
