﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * i2c.c
 *
 * Author: R9OFG (ex R0AEK)
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#include <inttypes.h>
#include <avr/io.h>
#include "i2c.h"

#define I2C_START		0x08
#define I2C_START_RPT	0x10
#define I2C_SLA_W_ACK	0x18
#define I2C_SLA_R_ACK	0x40
#define I2C_DATA_ACK	0x28
#define I2C_WRITE		0b11000000
#define I2C_READ		0b11000001

/*
 * Ограничение времени ожидания. Раньше ожидание флага TWINT было
 * бесконечным: при неисправной шине (нет Si5351, короткое замыкание)
 * микроконтроллер зависал навсегда.
 */
#define I2C_TIMEOUT		2000

static uint8_t i2cWaitTWINT(void)
{
	uint16_t timeout = I2C_TIMEOUT;

	while (!(TWCR & (1 << TWINT)))
	{
		if (--timeout == 0) return 1;
	}
	return 0;
}

static uint8_t i2cStart(void)
{
	TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
	if (i2cWaitTWINT()) return 0xFF;
	return (TWSR & 0xF8);
}

static void i2cStop(void)
{
	uint16_t timeout = I2C_TIMEOUT;

	TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWSTO);

	while (TWCR & (1 << TWSTO))
	{
		if (--timeout == 0) break;
	}
}

static uint8_t i2cByteSend(uint8_t data)
{
	TWDR = data;
	TWCR = (1 << TWINT) | (1 << TWEN);
	if (i2cWaitTWINT()) return 0xFF;
	return (TWSR & 0xF8);
}

uint8_t i2cSendRegister(uint8_t reg, uint8_t data)
{
	uint8_t stts;

	stts = i2cStart();
	if (stts != I2C_START) return 1;

	stts = i2cByteSend(I2C_WRITE);
	if (stts != I2C_SLA_W_ACK) return 2;

	stts = i2cByteSend(reg);
	if (stts != I2C_DATA_ACK) return 3;

	stts = i2cByteSend(data);
	if (stts != I2C_DATA_ACK) return 4;

	i2cStop();

	return 0;
}

void i2cInit(void)
{
	TWBR = 92;					/* ~125 кГц при F_CPU = 25 МГц */
	TWSR = 0;
	TWDR = 0xFF;
	PRR  = 0;
}
