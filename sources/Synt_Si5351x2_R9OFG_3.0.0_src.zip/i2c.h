﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * i2c.h
 *
 * Author: R9OFG (ex R0AEK)
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#ifndef I2C_H
#define I2C_H

#include <inttypes.h>

void    i2cInit(void);
uint8_t i2cSendRegister(uint8_t reg, uint8_t data);

#endif /* I2C_H */
