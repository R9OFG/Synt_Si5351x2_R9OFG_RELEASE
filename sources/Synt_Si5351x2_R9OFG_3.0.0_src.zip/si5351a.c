﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * si5351a.c
 *
 * Author: R9OFG (ex R0AEK)
 *
 * base on code from Hans Summers, 2015
 * Website: http://www.hanssummers.com
 * A very very simple Si5351a demonstration
 * using the Si5351a module kit http://www.hanssummers.com/synth
 * Please also refer to SiLabs AN619 which describes all the registers to use
 *
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#include <inttypes.h>
#include "Main.h"
#include "i2c.h"
#include "si5351a.h"

/*
 * Расчёт регистров PLL (AN619):
 *   P1 = 128 * mult + floor(128 * num / denom) - 512
 *   P2 = 128 * num - denom * floor(128 * num / denom)
 *   P3 = denom
 * mult = 15..90, num = 0..1048575, denom = 0..1048575.
 *
 * Все вычисления целочисленные: раньше промежуточные значения считались во
 * float, из-за чего num терял до 0.06 единицы, а это до ~50 Гц по выходу.
 */
static void setupPLL(uint8_t pll, uint8_t mult, uint32_t num, uint32_t denom)
{
	uint32_t p1;
	uint32_t p2;
	uint32_t p3;
	uint32_t div;

	div = (uint32_t)(((uint64_t)128 * num) / denom);

	p1 = 128UL * mult + div - 512UL;
	p2 = 128UL * num - denom * div;
	p3 = denom;

	i2cSendRegister(pll + 0, (uint8_t)((p3 & 0x0000FF00UL) >> 8));
	i2cSendRegister(pll + 1, (uint8_t)(p3 & 0x000000FFUL));
	i2cSendRegister(pll + 2, (uint8_t)((p1 & 0x00030000UL) >> 16));
	i2cSendRegister(pll + 3, (uint8_t)((p1 & 0x0000FF00UL) >> 8));
	i2cSendRegister(pll + 4, (uint8_t)(p1 & 0x000000FFUL));
	i2cSendRegister(pll + 5, (uint8_t)(((p3 & 0x000F0000UL) >> 12) | ((p2 & 0x000F0000UL) >> 16)));
	i2cSendRegister(pll + 6, (uint8_t)((p2 & 0x0000FF00UL) >> 8));
	i2cSendRegister(pll + 7, (uint8_t)(p2 & 0x000000FFUL));
}

/*
 * Настройка MultiSynth. Делитель целый, P2 = 0, P3 = 1, R-делитель = 1.
 */
static void setupMultisynth(uint8_t synth, uint32_t divider, uint8_t rDiv)
{
	uint32_t p1;

	p1 = 128UL * divider - 512UL;

	i2cSendRegister(synth + 0, 0x00);								/* P3 = 1 */
	i2cSendRegister(synth + 1, 0x01);
	i2cSendRegister(synth + 2, (uint8_t)(((p1 & 0x00030000UL) >> 16) | rDiv));
	i2cSendRegister(synth + 3, (uint8_t)((p1 & 0x0000FF00UL) >> 8));
	i2cSendRegister(synth + 4, (uint8_t)(p1 & 0x000000FFUL));
	i2cSendRegister(synth + 5, 0x00);								/* P3[19:16] | P2[19:16] */
	i2cSendRegister(synth + 6, 0x00);
	i2cSendRegister(synth + 7, 0x00);
}

/*
 * Выключение выходов: 1 - CLK0, 0 - CLK1/CLK2.
 */
void si5351aOutputOff(uint8_t value)
{
	if (value == 1)
	{
		i2cSendRegister(SI_CLK0_CONTROL, 0x80);
	}
	else
	{
		i2cSendRegister(SI_CLK1_CONTROL, 0x80);
		i2cSendRegister(SI_CLK2_CONTROL, 0x80);
	}
}

/*
 * Ток драйвера CLK0: 0 - 2 мА, 1 - 4 мА, 2 - 6 мА, 3 - 8 мА.
 */
void set_drvSt_si5351(uint8_t value)
{
	if (value > 3) value = 0;					/* защита от некорректного значения */

	i2cSendRegister(SI_CLK0_CONTROL, (uint8_t)(0x4C + value) | SI_CLK_SRC_PLL_A);
}

/*
 * Установка частоты на CLK0 выбранной микросхемы.
 * Частота в Гц, 1 МГц ... 60 МГц.
 *
 * PLL A настраивается на частоту около 900 МГц, MultiSynth 0 делит её до
 * требуемого значения с чётным целым делителем.
 */
void si5351aSetFrequency(uint32_t frequency, uint8_t chip)
{
	uint32_t pllFreq;
	uint32_t divider;
	uint32_t xtalFreq;
	uint32_t remainder;
	uint32_t num;

	/*
	 * Защита от некорректных значений. Попасть сюда можно, например, при
	 * переполнении разности частот (классическое преобразование, USB выше
	 * нулевых биений). Выход при этом сохраняет предыдущую частоту.
	 */
	if ((frequency < SI_FREQ_MIN) || (frequency > SI_FREQ_MAX)) return;

	/* делитель MultiSynth должен быть целым и чётным */
	divider = FREQ_PLLA / frequency;
	if (divider % 2) divider--;
	pllFreq = divider * frequency;

	/* опорная частота той микросхемы, которую программируем */
	xtalFreq = (chip == SI_CHIP_2) ? xtall_FREQ_2 : xtall_FREQ_1;
	if (xtalFreq == 0) xtalFreq = FREQ_XTALL_1_DEF;

	remainder = pllFreq % xtalFreq;
	num = (uint32_t)(((uint64_t)remainder * ACTUAL_MULTIPLIER) / xtalFreq);

	setupPLL(SI_SYNTH_PLL_A, (uint8_t)(pllFreq / xtalFreq), num, ACTUAL_MULTIPLIER);
	setupMultisynth(SI_SYNTH_MS_0, divider, SI_R_DIV_1);

	set_drvSt_si5351((chip == SI_CHIP_2) ? siDSC_2 : siDSC_1);
}
