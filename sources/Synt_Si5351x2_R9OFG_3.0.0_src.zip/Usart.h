﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * Usart.h
 *
 * Author: R9OFG (ex R0AEK)
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#ifndef USART_H_
#define USART_H_

#include <inttypes.h>

#define BAUD 57600					/* скорость работы USART */
#define MYUBRR (F_CPU / 16 / BAUD - 1)/* расчёт скорости передачи (нужен F_CPU) */

/* кольцевые буферы приёма и передачи (сами буферы — в Usart.c) */
#define BUFSIZERX 32
#define BUFSIZETX 32
#define BUFMASKRX (BUFSIZERX - 1)
#define BUFMASKTX (BUFSIZETX - 1)

/* максимальная длина принимаемой CAT-посылки вместе с ';' */
#define RX_MSG_MAX 16

void USART_Init(uint16_t ubrr);
void handlerRXUSART(void);
void handlerTXUSART(void);
void RX_Data_Parsing(void);
void CAT_IF_Send(void);
void CAT_ATT_PRE_Send(uint8_t value);

#endif /* USART_H_ */
