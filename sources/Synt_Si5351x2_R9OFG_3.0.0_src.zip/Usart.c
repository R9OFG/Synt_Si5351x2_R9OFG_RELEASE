﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * Usart.c
 *
 * Author: R9OFG (ex R0AEK)
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#include "Main.h"

/*--- кольцевые буферы ----------------------------------------------------*/
static char bufRX[BUFSIZERX];
static char bufTX[BUFSIZETX];
static volatile uint8_t rxIn, rxOut;
static volatile uint8_t txIn, txOut;

/*--- буферы обмена по CAT ------------------------------------------------*/
static uint8_t RX_array_Data[RX_MSG_MAX];
static char    TX_array_Data[20];
static char    strFreqVFO[10];

void USART_Init(uint16_t ubrr)
{
	/* установка скорости передачи */
	UBRR0H = (unsigned char)(ubrr >> 8);
	UBRR0L = (unsigned char)ubrr;
	/* прерывания RX/TX запрещены, приёмник и передатчик включены */
	UCSR0B = (0 << RXCIE0) | (0 << TXCIE0) | (1 << RXEN0) | (1 << TXEN0);
	/* 8 бит, без контроля чётности, 1 стоп-бит */
	UCSR0C = (0 << UMSEL01) | (0 << UMSEL00) | (0 << UPM01) | (0 << UPM00) |
	         (0 << USBS0) | (0 << UCSZ02) | (1 << UCSZ01) | (1 << UCSZ00);
	_delay_ms(50);
}

/*
 * Приём байта. При переполнении кольцевого буфера байт теряется, но
 * указатели остаются корректными.
 */
ISR(USART_RX_vect)
{
	char data = (char)UDR0;
	uint8_t next = (uint8_t)((rxIn + 1) & BUFMASKRX);

	if (next != rxOut)
	{
		bufRX[rxIn] = data;
		rxIn = next;
	}
}

/* очистка приёмного буфера сообщения (пробелы, как в версии 2.x) */
static void RX_Clear_Buffer(void)
{
	for (uint8_t i = 0; i < RX_MSG_MAX; i++)
		RX_array_Data[i] = ' ';
}

/*
 * Разбор принятых из USART данных. Раньше здесь была задержка 1 мс на
 * каждый байт (до 32 мс на посылку) — при кольцевом буфере она не нужна.
 */
void handlerRXUSART(void)
{
	static uint8_t i = 0;

	while (rxIn != rxOut)
	{
		char data = bufRX[rxOut];
		rxOut = (uint8_t)((rxOut + 1) & BUFMASKRX);

		if (i < RX_MSG_MAX)
			RX_array_Data[i++] = (uint8_t)data;

		if (data == ';')
		{
			if (i < RX_MSG_MAX)
				RX_Data_Parsing();
			else
				RX_Clear_Buffer();		/* посылка длиннее буфера — отбрасываем */

			i = 0;
		}
	}
}

/* передача байта из кольцевого буфера */
void handlerTXUSART(void)
{
	if ((txIn != txOut) && (UCSR0A & (1 << UDRE0)))
	{
		UDR0 = bufTX[txOut++];
		txOut &= BUFMASKTX;
	}
}

/* побайтовая загрузка кольцевого буфера передачи (с контролем переполнения) */
static void SendByteToCircularBuffer(uint8_t idx)
{
	for (uint8_t i = 0; i <= idx; i++)
	{
		uint8_t next = (uint8_t)((txIn + 1) & BUFMASKTX);

		if (next == txOut) break;		/* буфер полон */

		bufTX[txIn] = TX_array_Data[i];
		txIn = next;
	}
}

/*
 * Формирование 11-значного поля частоты с ведущими нулями.
 * Возвращает позицию, с которой начинаются значащие цифры.
 */
static uint8_t Freq_To_11_Digits(char *dst)
{
	ultoa(freq_VFO, strFreqVFO, 10);
	uint8_t len = (uint8_t)strlen(strFreqVFO);

	for (uint8_t i = 0; i < (uint8_t)(11 - len); i++)
		dst[i] = '0';

	for (uint8_t i = 0; i < len; i++)
		dst[11 - len + i] = strFreqVFO[i];

	return (uint8_t)(11 - len);
}

/* ответ на запрос "IF;" */
void CAT_IF_Send(void)
{
	TX_array_Data[0] = 'I';
	TX_array_Data[1] = 'F';

	Freq_To_11_Digits(&TX_array_Data[2]);

	TX_array_Data[13] = ' ';
	TX_array_Data[14] = (func_Mode == FUNC_MODE_TX) ? '1' : '0';
	TX_array_Data[15] = ' ';

	switch (but_MODE)
	{
		case 0:  TX_array_Data[16] = '1'; break;	/* LSB */
		case 1:  TX_array_Data[16] = '2'; break;	/* USB */
		case 2:  TX_array_Data[16] = '7'; break;	/* CWL */
		default: TX_array_Data[16] = '3'; break;	/* CWU */
	}

	TX_array_Data[17] = ';';
	SendByteToCircularBuffer(17);
}

/* ответ на запрос "APS;" (Value = 1) и на смену режима ATT/PRE (Value = 0) */
void CAT_ATT_PRE_Send(uint8_t value)
{
	TX_array_Data[0] = 'A';

	if (value == 1)
	{
		TX_array_Data[1] = 'P';
		TX_array_Data[2] = 'S';
	}
	else
	{
		TX_array_Data[1] = '_';
		TX_array_Data[2] = 'P';
	}

	TX_array_Data[3] = (char)('0' + but_ATT_PRE);
	TX_array_Data[4] = ';';
	SendByteToCircularBuffer(4);
}

/*--- расширенные настройки синтезатора (команды приложения) --------------*/

static uint8_t CAT_Prefix(char c0, char c1)
{
	return (uint8_t)((RX_array_Data[0] == (uint8_t)c0) && (RX_array_Data[1] == (uint8_t)c1));
}

/* команда без значения: "XX;" */
static uint8_t CAT_Is_Query(void)
{
	return (uint8_t)(RX_array_Data[2] == ';');
}

/* число после префикса, до нецифрового символа */
static uint32_t CAT_Parse_Number(uint8_t start)
{
	uint32_t value = 0;

	for (uint8_t i = start; i < RX_MSG_MAX; i++)
	{
		uint8_t c = RX_array_Data[i];

		if ((c < '0') || (c > '9')) break;

		value = value * 10 + (uint32_t)(c - '0');

		if (value > 60000000UL) { value = 60000000UL; break; }
	}

	return value;
}

/* несколько цифр подряд (маски BS/AT) */
static uint8_t CAT_Parse_Digits(uint8_t start, uint8_t *values, uint8_t count)
{
	for (uint8_t i = 0; i < count; i++)
	{
		uint8_t idx = (uint8_t)(start + i);
		uint8_t c;

		if (idx >= RX_MSG_MAX) return 0;

		c = RX_array_Data[idx];

		if ((c < '0') || (c > '9')) return 0;

		values[i] = (uint8_t)(c - '0');
	}

	return 1;
}

/* ответ "префикс<число>;" */
static void CAT_Send_Value(const char *prefix, uint32_t value)
{
	uint8_t len;
	uint8_t n = 0;

	while ((prefix[n] != '\0') && (n < 3))
	{
		TX_array_Data[n] = prefix[n];
		n++;
	}

	ultoa(value, strFreqVFO, 10);
	len = (uint8_t)strlen(strFreqVFO);

	for (uint8_t i = 0; i < len; i++)
		TX_array_Data[n + i] = strFreqVFO[i];

	TX_array_Data[n + len] = ';';
	SendByteToCircularBuffer((uint8_t)(n + len));
}

/* ответ "префикс<цифры>;" */
static void CAT_Send_Digits(const char *prefix, const uint8_t *values, uint8_t count)
{
	uint8_t n = 0;

	while ((prefix[n] != '\0') && (n < 3))
	{
		TX_array_Data[n] = prefix[n];
		n++;
	}

	for (uint8_t i = 0; i < count; i++)
		TX_array_Data[n + i] = (char)('0' + values[i]);

	TX_array_Data[n + count] = ';';
	SendByteToCircularBuffer((uint8_t)(n + count));
}

/*
 * Настройки синтезатора из приложения:
 *   VR;                     версия прошивки
 *   ST; / STn;              шаг перестройки (0...6)
 *   LS/US/LC/UC; / ...nnn;  BFO LSB/USB/CWL/CWU
 *   XT1; / XT1nnn;  XT2;    калибровка опоры
 *   DR; / DRxy;             ток CLK0 Si5351-1/2 (0...3)
 *   CV; / CVn;              преобразование (0 - классика, 1 - всегда вверх)
 *   SW; / SWn;              смена частот VFO/BFO при TX
 *   BS; / BSxxxxxxxxx;      включение 9 диапазонов
 *   AT; / ATxxxxxxxxx;      ATT/PRE по 9 диапазонам
 */
static void CAT_Settings_Parsing(void)
{
	uint8_t digits[BANDS_COUNT];
	const char *ver;
	uint8_t n;

	/* сервисные команды выполняются только в основном режиме */
	if (func_Mode != FUNC_MODE_NORMAL) return;

	/* версия прошивки */
	if (CAT_Prefix('V', 'R') && CAT_Is_Query())
	{
		ver = FW_VERSION_STRING;
		n = 0;

		TX_array_Data[0] = 'V';
		TX_array_Data[1] = 'R';

		while ((ver[n] != '\0') && (n < 10))
		{
			TX_array_Data[2 + n] = ver[n];
			n++;
		}

		TX_array_Data[2 + n] = ';';
		SendByteToCircularBuffer((uint8_t)(2 + n));
		return;
	}

	/* шаг перестройки */
	if (CAT_Prefix('S', 'T'))
	{
		if (!CAT_Is_Query()) CAT_Set_STEP((uint8_t)CAT_Parse_Number(2));

		CAT_Send_Value("ST", set_Step_index);
		return;
	}

	/* частоты BFO */
	if (CAT_Prefix('L', 'S') || CAT_Prefix('U', 'S') ||
	    CAT_Prefix('L', 'C') || CAT_Prefix('U', 'C'))
	{
		uint8_t index = 0;

		if (RX_array_Data[0] == 'U') index += 1;
		if (RX_array_Data[1] == 'C') index += 2;

		if (!CAT_Is_Query())
		{
			CAT_Set_BFO(index, CAT_Parse_Number(2));
		}

		switch (index)
		{
			case 0:  CAT_Send_Value("LS", freq_BFO_LSB); break;
			case 1:  CAT_Send_Value("US", freq_BFO_USB); break;
			case 2:  CAT_Send_Value("LC", freq_BFO_CWL); break;
			default: CAT_Send_Value("UC", freq_BFO_CWU); break;
		}

		return;
	}

	/* калибровка опоры */
	if (CAT_Prefix('X', 'T') && ((RX_array_Data[2] == '1') || (RX_array_Data[2] == '2')))
	{
		uint8_t index = (RX_array_Data[2] == '2') ? 1 : 0;

		if (RX_array_Data[3] != ';')
		{
			CAT_Set_XTALL(index, CAT_Parse_Number(3));
		}

		CAT_Send_Value(index ? "XT2" : "XT1", index ? xtall_FREQ_2 : xtall_FREQ_1);
		return;
	}

	/* ток драйвера CLK0 */
	if (CAT_Prefix('D', 'R'))
	{
		if (!CAT_Is_Query() && CAT_Parse_Digits(2, digits, 2))
		{
			CAT_Set_DRV(digits[0], digits[1]);
		}

		digits[0] = siDSC_1;
		digits[1] = siDSC_2;
		CAT_Send_Digits("DR", digits, 2);
		return;
	}

	/* вариант преобразования */
	if (CAT_Prefix('C', 'V'))
	{
		if (!CAT_Is_Query()) CAT_Set_CONVERSION((uint8_t)CAT_Parse_Number(2));

		CAT_Send_Value("CV", var_Conversion);
		return;
	}

	/* смена частот при TX */
	if (CAT_Prefix('S', 'W'))
	{
		if (!CAT_Is_Query()) CAT_Set_SWAP((uint8_t)CAT_Parse_Number(2));

		CAT_Send_Value("SW", var_Swap_F_TX);
		return;
	}

	/* включение диапазонов */
	if (CAT_Prefix('B', 'S'))
	{
		if (!CAT_Is_Query() && CAT_Parse_Digits(2, digits, BANDS_COUNT))
		{
			CAT_Set_BAND_USE(digits);
		}

		CAT_Send_Digits("BS", band_use, BANDS_COUNT);
		return;
	}

	/* ATT/PRE по диапазонам */
	if (CAT_Prefix('A', 'T'))
	{
		if (!CAT_Is_Query() && CAT_Parse_Digits(2, digits, BANDS_COUNT))
		{
			CAT_Set_ATT_PRE(digits);
		}

		CAT_Send_Digits("AT", att_pre, BANDS_COUNT);
		return;
	}

	/* калибровка S-метра: "SCn;" / "SCnvvv;" (n = 0...6, vvv = 0...255) */
	if (CAT_Prefix('S', 'C') && (RX_array_Data[2] >= '0') && (RX_array_Data[2] <= '6'))
	{
		uint8_t index = (uint8_t)(RX_array_Data[2] - '0');
		uint32_t value = CAT_Parse_Number(3);
		uint8_t len;

		if (RX_array_Data[3] != ';')
		{
			if (value > 255) value = 255;
			CAT_Set_SMETER(index, (uint8_t)value);
		}

		ultoa(smetr_cal[index], strFreqVFO, 10);
		len = (uint8_t)strlen(strFreqVFO);

		TX_array_Data[0] = 'S';
		TX_array_Data[1] = 'C';
		TX_array_Data[2] = RX_array_Data[2];

		for (uint8_t i = 0; i < len; i++)
			TX_array_Data[3 + i] = strFreqVFO[i];

		TX_array_Data[3 + len] = ';';
		SendByteToCircularBuffer((uint8_t)(3 + len));
		return;
	}

	/* "SM;" — текущее показание АЦП S-метра: "SMnnn;" (сглаженное) */
	if (CAT_Prefix('S', 'M') && CAT_Is_Query())
	{
		uint8_t value = data_ADC_1_filt;

		TX_array_Data[0] = 'S';
		TX_array_Data[1] = 'M';
		TX_array_Data[2] = (char)('0' + (value / 100));
		TX_array_Data[3] = (char)('0' + ((value / 10) % 10));
		TX_array_Data[4] = (char)('0' + (value % 10));
		TX_array_Data[5] = ';';
		SendByteToCircularBuffer(5);
		return;
	}
}

void RX_Data_Parsing(void)
{
	/* запрос "IF;" — чтение состояния синтезатора */
	if ((RX_array_Data[0] == 'I') && (RX_array_Data[1] == 'F') && (RX_array_Data[2] == ';'))
	{
		CAT_IF_Send();
	}

	/* запрос "FA;" — чтение частоты VFO-A */
	if ((RX_array_Data[0] == 'F') && (RX_array_Data[1] == 'A') && (RX_array_Data[2] == ';'))
	{
		TX_array_Data[0] = 'F';
		TX_array_Data[1] = 'A';

		Freq_To_11_Digits(&TX_array_Data[2]);

		TX_array_Data[13] = ';';
		SendByteToCircularBuffer(13);
	}

	/* запрос "FAxxxxxxxxxxx;" — установка частоты VFO-A (только в режиме приёма) */
	if ((RX_array_Data[0] == 'F') && (RX_array_Data[1] == 'A') &&
	    (RX_array_Data[13] == ';') && (func_Mode == FUNC_MODE_NORMAL))
	{
		char freqStr[12];
		uint32_t oldFreqVFO = freq_VFO;

		for (uint8_t i = 0; i < 11; i++)
			freqStr[i] = (char)RX_array_Data[i + 2];
		freqStr[11] = '\0';				/* строка обязательно должна быть закрыта */

		freq_VFO = (uint32_t)atol(freqStr);

		/* для WSJT-X/JTDX: относительная перестройка */
		if (freq_VFO == 55) freq_VFO += oldFreqVFO;

		if ((freq_VFO >= FREQ_VFO_MIN) && (freq_VFO <= FREQ_VFO_MAX))
		{
			Check_BAND();
			Freq_format_to_LCD(freq_VFO, 6, 0);
			timerCountSaveBandData = 0;
		}
		else
		{
			freq_VFO = oldFreqVFO;
		}
	}

	/* "MD1;" — LSB, "MD2;" — USB */
	if ((RX_array_Data[0] == 'M') && (RX_array_Data[1] == 'D') &&
	    ((RX_array_Data[2] == '1') || (RX_array_Data[2] == '2')) && (RX_array_Data[3] == ';'))
	{
		but_MODE = (RX_array_Data[2] == '1') ? 0 : 1;
		Check_Conversion();
	}

	/* "MD7;" — CWL, "MD3;" — CWU */
	if ((RX_array_Data[0] == 'M') && (RX_array_Data[1] == 'D') &&
	    ((RX_array_Data[2] == '7') || (RX_array_Data[2] == '3')) && (RX_array_Data[3] == ';'))
	{
		but_MODE = (RX_array_Data[2] == '7') ? 2 : 3;
		Check_Conversion();
	}

	/* "RX;" — переход в режим приёма */
	if ((RX_array_Data[0] == 'R') && (RX_array_Data[1] == 'X') && (RX_array_Data[2] == ';'))
	{
		if (func_Mode == FUNC_MODE_TX)
		{
			ptt_cat_ON_F = 0;
			PTT_ON(0);
		}

		/* ответ нужен для WSJT-X/JTDX */
		TX_array_Data[0] = 'R';
		TX_array_Data[1] = 'X';
		TX_array_Data[2] = ';';
		SendByteToCircularBuffer(2);
	}

	/* "TX;" — переход в режим передачи */
	if ((RX_array_Data[0] == 'T') && (RX_array_Data[1] == 'X') &&
	    (RX_array_Data[2] == ';') && (func_Mode == FUNC_MODE_NORMAL))
	{
		ptt_cat_ON_F = 1;
		PTT_ON(1);
	}

	/*--- команды, которых нет в OmniRig -------------------------------*/

	/* "BN0;" — диапазон вниз */
	if ((RX_array_Data[0] == 'B') && (RX_array_Data[1] == 'N') &&
	    (RX_array_Data[2] == '0') && (RX_array_Data[3] == ';') && (func_Mode == FUNC_MODE_NORMAL))
	{
		Change_Band(-1);
	}

	/* "BN1;" — диапазон вверх */
	if ((RX_array_Data[0] == 'B') && (RX_array_Data[1] == 'N') &&
	    (RX_array_Data[2] == '1') && (RX_array_Data[3] == ';') && (func_Mode == FUNC_MODE_NORMAL))
	{
		Change_Band(1);
	}

	/* "A_P;" — смена режима ATT/PRE (ATT -> нет -> PRE -> нет) */
	if ((RX_array_Data[0] == 'A') && (RX_array_Data[1] == '_') &&
	    (RX_array_Data[2] == 'P') && (RX_array_Data[3] == ';') && (func_Mode == FUNC_MODE_NORMAL))
	{
		ATT_PRE_Toggle();			/* ответ отправляется из этой функции */
	}

	/* "TNx;" — режим тональника: 0 - нет, 1 - один тон, 2 - два тона */
	if ((RX_array_Data[0] == 'T') && (RX_array_Data[1] == 'N') &&
	    (RX_array_Data[2] >= '0') && (RX_array_Data[2] <= '2') &&
	    (RX_array_Data[3] == ';'))
	{
		CAT_Set_Tone_Mode((uint8_t)(RX_array_Data[2] - '0'));
	}

	/* "APS;" — чтение состояния ATT/PRE */
	if ((RX_array_Data[0] == 'A') && (RX_array_Data[1] == 'P') &&
	    (RX_array_Data[2] == 'S') && (RX_array_Data[3] == ';') && (func_Mode == FUNC_MODE_NORMAL))
	{
		CAT_ATT_PRE_Send(1);
	}

	/*--- расширенные настройки (команды приложения) ----------------------*/
	CAT_Settings_Parsing();

	RX_Clear_Buffer();
}
