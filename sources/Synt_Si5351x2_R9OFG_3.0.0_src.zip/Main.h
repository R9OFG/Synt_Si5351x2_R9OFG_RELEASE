﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * Main.h
 *
 * Author: R9OFG (ex R0AEK)
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#ifndef MAIN_H_
#define MAIN_H_

#define F_CPU 25000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <stdlib.h>
#include <string.h>

#include "Lcd_1602.h"
#include "si5351a.h"
#include "i2c.h"
#include "Usart.h"

/*--- версия прошивки -----------------------------------------------------*/
/*
 * Версия задаётся только здесь и выводится на LCD в заставке.
 * Формат: MAJOR.MINOR.PATCH (например 3.0.0).
 * Номер релиза поднимается вручную, по команде — автоинкремента нет.
 */
#define FW_VERSION_MAJOR	3
#define FW_VERSION_MINOR	0
#define FW_VERSION_PATCH	0

#define FW_STR_(x)			#x
#define FW_STR(x)			FW_STR_(x)
#define FW_VERSION_STRING	FW_STR(FW_VERSION_MAJOR) "." FW_STR(FW_VERSION_MINOR) "." FW_STR(FW_VERSION_PATCH)

/*--- пределы перестройки, Гц ---------------------------------------------*/
#define FREQ_VFO_MIN			1000000UL		/* нижняя граница VFO */
#define FREQ_VFO_MAX			29999999UL		/* верхняя граница VFO */
#define FREQ_BFO_MIN			1000000UL		/* нижняя граница BFO (см. SI_FREQ_MIN) */
#define FREQ_XTALL_MIN			10000000UL		/* нижняя граница настройки опоры */
#define FREQ_XTALL_MAX			30000000UL		/* верхняя граница настройки опоры */

/*--- значения по умолчанию -----------------------------------------------*/
#define FREQ_LSB_DEF			8865000UL		/* BFO SSB LOW */
#define FREQ_USB_DEF			8868000UL		/* BFO SSB HIGH */
#define FREQ_CWL_DEF			8865000UL		/* BFO CW LOW */
#define FREQ_CWU_DEF			8868000UL		/* BFO CW HIGH */
#define FREQ_XTALL_1_DEF		25000000UL		/* опора Si5351-1 (VFO) */
#define FREQ_XTALL_2_DEF		25000000UL		/* опора Si5351-2 (BFO) */

/*--- энкодер и регистр сдвига --------------------------------------------*/
#define ENCODER_MASK			0x0C			/* входы энкодера PD2, PD3 */
#define SR_CLOCK				PD4				/* тактовый вход регистра сдвига */
#define SR_DATA					PD5				/* данные регистра сдвига */
#define SR_LATCH				PD6				/* защёлка регистра сдвига */
#define SW_I2C					PC3				/* выбор микросхемы по линии SCL1 */

/*--- режимы работы -------------------------------------------------------*/
#define FUNC_MODE_NORMAL		1				/* основной режим (RX) */
#define FUNC_MODE_TX			2				/* передача (TX) */
#define FUNC_MODE_SET_STEP		3				/* выбор шага перестройки */
#define FUNC_MODE_SET_BFO_LSB	4				/* настройка BFO_LSB */
#define FUNC_MODE_SET_BFO_USB	5				/* настройка BFO_USB */
#define FUNC_MODE_SET_BFO_CWL	6				/* настройка BFO_CWL */
#define FUNC_MODE_SET_BFO_CWU	7				/* настройка BFO_CWU */
#define FUNC_MODE_SET_XTALL_1	8				/* калибровка опоры Si5351-1 */
#define FUNC_MODE_SET_XTALL_2	9				/* калибровка опоры Si5351-2 */
#define FUNC_MODE_SET_DRV_ST_1	10				/* ток драйвера CLK0 Si5351-1 */
#define FUNC_MODE_SET_DRV_ST_2	11				/* ток драйвера CLK0 Si5351-2 */
#define FUNC_MODE_SET_CONV		12				/* вариант преобразования */
#define FUNC_MODE_SET_SWP_F_TX	13				/* смена частот VFO/BFO при TX */
#define FUNC_MODE_SET_BAND		14				/* разрешение диапазонов */

/*--- номера диапазонов ---------------------------------------------------*/
#define BAND_160m				1
#define BAND_80m				2
#define BAND_40m				3
#define BAND_30m				4
#define BAND_20m				5
#define BAND_17m				6
#define BAND_15m				7
#define BAND_12m				8
#define BAND_10m				9

/*--- верхние границы диапазонов, Гц --------------------------------------*/
#define BAND_1_MAX				2499999UL		/* 160 m */
#define BAND_2_MAX				4499999UL		/* 80 m */
#define BAND_3_MAX				7999999UL		/* 40 m */
#define BAND_4_MAX				11999999UL		/* 30 m */
#define BAND_5_MAX				15999999UL		/* 20 m */
#define BAND_6_MAX				19999999UL		/* 17 m */
#define BAND_7_MAX				23999999UL		/* 15 m */
#define BAND_8_MAX				25999999UL		/* 12 m */

/*--- кнопки --------------------------------------------------------------*/
#define BUT_NULL				0
#define BUT_FUNC				1
#define BUT_ATT_PRE				2
#define BUT_PTT					3
#define BUT_MODE				4

/*--- карта EEPROM --------------------------------------------------------*/
/*
 * 00		маркер формата данных (EE_FORMAT_MARK)
 * 01		резерв
 * 02		индекс шага перестройки							1 байт
 * 03		последний активный диапазон						1 байт
 * 04		частота BFO_LSB									4 байта (dword)
 * 08		частота XTALL_1									4 байта
 * 12		частота диапазона 160m							4 байта
 * 16		частота диапазона 80m							4 байта
 * 20		частота диапазона 40m							4 байта
 * 24		частота диапазона 30m							4 байта
 * 28		частота диапазона 20m							4 байта
 * 32		частота диапазона 17m							4 байта
 * 36		частота диапазона 15m							4 байта
 * 40		частота диапазона 12m							4 байта
 * 44		частота диапазона 10m							4 байта
 * 48		статусы ATT/PRE диапазонов						9 байт
 * 57		разрешение диапазонов							9 байт
 * 66		ток драйвера CLK0 Si5351-1						1 байт
 * 67		частота BFO_USB									4 байта
 * 71		частота XTALL_2									4 байта
 * 75		ток драйвера CLK0 Si5351-2						1 байт
 * 76		частота BFO_CWL									4 байта
 * 80		частота BFO_CWU									4 байта
 * 84		вариант преобразования							1 байт
 * 85		смена частот VFO/BFO_xxx при TX					1 байт
 *
 * Частоты хранятся целым числом (dword), а не float: float терял 1...2 Гц
 * у значений выше 16777216 Гц (10 м диапазон, опора 25 МГц).
 */
#define EE_ADDR_FORMAT			0x00
#define EE_ADDR_STEP			0x02
#define EE_ADDR_BAND			0x03
#define EE_ADDR_BFO_LSB			0x04
#define EE_ADDR_XTALL_1			0x08
#define EE_ADDR_BAND_FREQ		12			/* + 4 * (номер диапазона - 1) */
#define EE_ADDR_ATT_PRE			48			/* + (номер диапазона - 1) */
#define EE_ADDR_BAND_USE		57			/* + (номер диапазона - 1) */
#define EE_ADDR_DRV_ST_1		66
#define EE_ADDR_BFO_USB			67
#define EE_ADDR_XTALL_2			71
#define EE_ADDR_DRV_ST_2		75
#define EE_ADDR_BFO_CWL			76
#define EE_ADDR_BFO_CWU			80
#define EE_ADDR_CONV			84
#define EE_ADDR_SWAP_TX			85
#define EE_ADDR_SMETR_CAL		86			/* 7 порогов S-метра, + (0...6) */
#define EE_ADDR_SMETR_TYPE		93			/* признак шкалы S-метра (опора 1,1 В) */
#define EE_FORMAT_MARK			0x3A		/* версия формата данных 3.0 */
#define SMETR_TYPE_1V1			0xB6		/* шкала АЦП: 0...1,2 В (10 бит на AVcc) */

/* сколько диапазонов в проекте */
#define BANDS_COUNT	9

/* пороги калибровки S-метра (7 «кубиков») */
#define SMETR_CAL_COUNT	7

/*--- переменные, общие для нескольких модулей ----------------------------*/
extern uint8_t  func_Mode;
extern uint8_t  but_MODE;
extern uint8_t  but_ATT_PRE;
extern uint8_t  ptt_cat_ON_F;
extern unsigned char band_Num;
extern uint8_t  band_use[9];
extern uint8_t  att_pre[9];
extern uint8_t  set_Step_index;
extern uint32_t freq_VFO;
extern uint32_t freq_BFO_LSB;
extern uint32_t freq_BFO_USB;
extern uint32_t freq_BFO_CWL;
extern uint32_t freq_BFO_CWU;
extern uint32_t xtall_FREQ_1;
extern uint32_t xtall_FREQ_2;
extern uint8_t  siDSC_1;
extern uint8_t  siDSC_2;
extern uint8_t  var_Conversion;
extern uint8_t  var_Swap_F_TX;
extern uint8_t  smetr_cal[SMETR_CAL_COUNT];
extern volatile unsigned char data_ADC_1;
extern volatile unsigned char data_ADC_1_filt;
extern volatile uint16_t timerCountSaveBandData;

/*--- функции, вызываемые из других модулей -------------------------------*/
void PTT_ON(uint8_t value);
void ATT_PRE_Set(void);
void ATT_PRE_Toggle(void);
void Check_Conversion(void);
void Set_MODE(void);
void Freq_format_to_LCD(uint32_t freq, uint8_t col, uint8_t str);
void Check_BAND(void);
void Set_BAND(void);
void Change_Band(int8_t dir);

/*--- установки синтезатора по CAT (команды приложения) -------------------*/
void CAT_Set_BFO(uint8_t index, uint32_t freq);			/* 0-LSB, 1-USB, 2-CWL, 3-CWU */
void CAT_Set_XTALL(uint8_t index, uint32_t freq);		/* 0-XT1, 1-XT2 */
void CAT_Set_STEP(uint8_t index);
void CAT_Set_DRV(uint8_t drive1, uint8_t drive2);
void CAT_Set_CONVERSION(uint8_t value);
void CAT_Set_SWAP(uint8_t value);
void CAT_Set_BAND_USE(const uint8_t *mask);
void CAT_Set_ATT_PRE(const uint8_t *values);
void CAT_Set_SMETER(uint8_t index, uint8_t value);

#endif /* MAIN_H_ */
