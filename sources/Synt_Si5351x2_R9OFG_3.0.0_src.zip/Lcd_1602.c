﻿/*
 * HF synthesizer
 * base on Si5351x2
 * 9 - bands
 *
 * Lcd_1602.c
 *
 * Author: R9OFG (ex R0AEK)
 * Version - 3.0.0
 *
 * info@r9ofg.ru
 * https://r9ofg.ru
 */

#include "Main.h"
#include "Lcd_1602.h"

/*
 * Знакогенератор S-метра: 0 — значок антенны (это не кубик), 1...7 — кубики
 * высотой 1...7 строк. Всего 8 знакомест (0...7) — столько и даёт CGRAM.
 * Все значки занимают строки 0...6: 8-я строка знакогенератора у многих
 * индикаторов отводится под курсор и не отображается.
 */
static const uint8_t Ant_Char[8]  PROGMEM = {0b00000,0b00000,0b10101,0b01110,0b00100,0b00100,0b00100,0b00000};
static const uint8_t Bar1_Char[8] PROGMEM = {0b00000,0b00000,0b00000,0b00000,0b00000,0b00000,0b11111,0b00000};
static const uint8_t Bar2_Char[8] PROGMEM = {0b00000,0b00000,0b00000,0b00000,0b00000,0b11111,0b11111,0b00000};
static const uint8_t Bar3_Char[8] PROGMEM = {0b00000,0b00000,0b00000,0b00000,0b11111,0b10001,0b11111,0b00000};
static const uint8_t Bar4_Char[8] PROGMEM = {0b00000,0b00000,0b00000,0b11111,0b10001,0b10001,0b11111,0b00000};
static const uint8_t Bar5_Char[8] PROGMEM = {0b00000,0b00000,0b11111,0b10001,0b10001,0b10001,0b11111,0b00000};
static const uint8_t Bar6_Char[8] PROGMEM = {0b00000,0b11111,0b11111,0b11111,0b11111,0b11111,0b11111,0b00000};
static const uint8_t Bar7_Char[8] PROGMEM = {0b11111,0b11111,0b11111,0b11111,0b11111,0b11111,0b11111,0b00000};

/*
 * Выдача полубайта в LCD. Сначала устанавливаются данные, затем формируется
 * импульс E (у HD44780 данные должны быть готовы до фронта E).
 */
void LCD_send_half_byte(uint8_t c)
{
	PORTB = (uint8_t)((c << 1) & 0x1E);		/* данные в PB4..PB1, E = 0 */
	_delay_us(2);
	E_1;
	_delay_us(40);
	E_0;
	_delay_us(40);							/* пауза на выполнение команды (37 мкс) */
	PORTB = 0x00;
}

void LCD_send_byte(uint8_t c, uint8_t mode)
{
	if (mode == 0) RS_0;
	else           RS_1;

	LCD_send_half_byte((uint8_t)(c >> 4));	/* старший полубайт */
	LCD_send_half_byte((uint8_t)(c & 0x0F));	/* младший полубайт */
}

void LCD_define_char(const uint8_t *pc, uint8_t char_code)
{
	uint8_t a = (uint8_t)((char_code << 3) | 0x40);

	for (uint8_t i = 0; i < 8; i++)
	{
		LCD_send_byte(a++, 0);
		LCD_send_byte(pgm_read_byte(pc + i), 1);
	}
}

void LCD_send_char(uint8_t c)
{
	LCD_send_byte(c, 1);
}

void LCD_send_str(const char *str)
{
	while (*str) LCD_send_char((uint8_t)*str++);
}

/* строка находится в FLASH (PSTR) */
void LCD_send_str_P(const char *str)
{
	char c;

	while ((c = (char)pgm_read_byte(str++)) != '\0')
		LCD_send_char((uint8_t)c);
}

void LCD_send_str_delay_P(const char *str)
{
	char c;

	while ((c = (char)pgm_read_byte(str++)) != '\0')
	{
		LCD_send_char((uint8_t)c);
		_delay_ms(25);
	}
}

void LCD_set_pos(uint8_t x, uint8_t y)
{
	uint8_t adress = (uint8_t)((0x40 * y + x) | 0b10000000);
	LCD_send_byte(adress, 0);
}

/* загрузка значков S-метра в CGRAM: 0 — антенна, 1...7 — кубики */
static void LCD_define_smeter_chars(void)
{
	LCD_define_char(Ant_Char,  0x00);
	_delay_ms(10);
	LCD_define_char(Bar1_Char, 0x01);
	_delay_ms(10);
	LCD_define_char(Bar2_Char, 0x02);
	_delay_ms(10);
	LCD_define_char(Bar3_Char, 0x03);
	_delay_ms(10);
	LCD_define_char(Bar4_Char, 0x04);
	_delay_ms(10);
	LCD_define_char(Bar5_Char, 0x05);
	_delay_ms(10);
	LCD_define_char(Bar6_Char, 0x06);
	_delay_ms(10);
	LCD_define_char(Bar7_Char, 0x07);
	_delay_ms(10);
}

void LCD_ini(void)
{
	LCD_send_half_byte(0x03);			/* 8 бит, 1 строка */
	_delay_ms(40);
	LCD_send_half_byte(0x02);			/* 4 бита, 1 строка */
	_delay_ms(40);
	LCD_send_byte(0x28, 0);				/* 4 бита, 2 строки, шрифт 5x8 */
	_delay_ms(40);
	LCD_send_byte(0x06, 0);				/* курсор вправо, без сдвига экрана */
	_delay_ms(40);

	/* значки S-метра: грузим и здесь, и в конце (см. ниже) */
	LCD_define_smeter_chars();

	LCD_send_byte(0x0C, 0);				/* включаем экран, курсор выключен */
	_delay_ms(40);
	LCD_send_byte(0x01, 0);				/* очистка экрана */
	_delay_ms(5);

	/* заставка */
	_delay_ms(10);
	LCD_set_pos(1, 0);
	_delay_ms(10);
	LCD_send_str_delay_P(PSTR("HF synthesizer"));
	_delay_ms(1000);

	LCD_set_pos(0, 1);
	_delay_ms(10);
	LCD_send_str_delay_P(PSTR("   Si5351 x 2   "));
	_delay_ms(2000);

	LCD_send_byte(0x01, 0);				/* очистка экрана */
	_delay_ms(10);
	LCD_set_pos(4, 0);
	_delay_ms(10);
	LCD_send_str_delay_P(PSTR("By R9OFG"));
	_delay_ms(1000);

	LCD_set_pos((uint8_t)((16 - (sizeof("Ver: " FW_VERSION_STRING) - 1)) / 2), 1);
	LCD_send_str_delay_P(PSTR("Ver: " FW_VERSION_STRING));
	_delay_ms(2000);

	LCD_send_byte(0x01, 0);				/* очистка экрана */
	_delay_ms(5);						/* очистка занимает 1.52 мс */

	/* повторная загрузка значков — страховка от сбоя первой записи */
	LCD_define_smeter_chars();
}
